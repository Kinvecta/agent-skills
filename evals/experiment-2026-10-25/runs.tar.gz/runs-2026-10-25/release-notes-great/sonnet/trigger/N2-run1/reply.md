I can't summarize the PR yet because I don't have one to read. `/home/dev/project` isn't a git repository, so there's no branch or diff. `gh pr view` also failed, since there's no repo to infer a PR from. The directory only holds `.claude` and `skills` folders.

Any of these would let me write the summary:
- **A PR URL or number**, plus the repo if it isn't the one `gh` would pick up. I'll fetch it with `gh pr view` and `gh pr diff`.
- **The repo's location**, if it's cloned somewhere else on this machine.
- **The diff or description pasted here.**

Once I have one, I'll write a reviewer-oriented summary covering what changed and why, the files and areas to look at most closely, risks, and how it was tested.