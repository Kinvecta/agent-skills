I can't write an accurate tweet yet. The project has no changelog, version file, or git history, so I don't know what's in the release.

Send me any of these and I'll draft it:
- The product name and version number
- The 2–3 headline changes or features
- A link, if you want one included
- The tone you want (excited, understated, technical)

Here's a template you can fill in meanwhile:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Fix or smaller win]
>
> Details: [link]

If you paste a list of merged changes or a git log, I can also write full release notes with the `release-notes` skill and then condense them into the tweet.