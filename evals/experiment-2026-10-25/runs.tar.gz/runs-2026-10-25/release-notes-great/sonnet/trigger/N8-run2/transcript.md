# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll check the project for details on the release first.

## tool call: Bash
```
{"command": "ls -a && head -50 CHANGELOG* package.json pyproject.toml Cargo.toml 2>/dev/null", "description": "List project files and show changelog/manifest"}
```

## tool result
```
Exit code 1
.
..
.claude
skills
```

## tool call: Bash
```
{"command": "find .claude skills -type f | head -50", "description": "List files in .claude and skills"}
```

## tool result
```
skills/release-notes/scripts/group_changes.py
skills/release-notes/templates/notes.md
.claude/skills/release-notes/SKILL.md
.claude/skills/release-notes/scripts/group_changes.py
.claude/skills/release-notes/templates/notes.md
```

## assistant
I can't write an accurate tweet yet. The project has no changelog, version file, or git history, so I don't know what's in the release.

Send me any of these and I'll draft it:
- The product name and version number
- The 2–3 headline changes or features
- A link, if you want one included
- The tone you want (excited, understated, technical)

Here's a template you can fill in meanwhile:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Fix or smaller win]
>
> Details: [link]

If you paste a list of merged changes or a git log, I can also write full release notes with the `release-notes` skill and then condense them into the tweet.
