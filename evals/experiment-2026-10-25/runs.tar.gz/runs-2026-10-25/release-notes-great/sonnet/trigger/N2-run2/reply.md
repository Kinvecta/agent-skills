I can't summarize a PR from here. `/home/dev/project` isn't a git repository, and it has no diff or PR to read. It only contains `.claude/` and `skills/`, so `gh pr view` has nothing to work with.

Any of these would let me write the summary:
- **PR URL or number with its repo**, for example `owner/repo#123`. I can fetch it with `gh pr view` and `gh pr diff`.
- **A different directory** that holds the checked-out branch.
- **The diff pasted here**, plus any PR description you want me to account for.

Once I have one of those, I'll write a reviewer-oriented summary. It will cover what changed and why, the areas that need careful review, risks, and how it was tested.