I can't draft the 1.5.0 notes yet because I have no list of changes to work from. `/home/dev/project` isn't a git repository, so I can't export a log. There's also no changelog or log export file in the directory.

I need one of these from you:

- **A git log export.** Run `git log <previous-tag>..<new-tag> > changes.txt` in the real repo and tell me where the file is. I can also work from a copy of the repo.
- **Pasted text.** A list of the merged PRs or commits since the last release works.

Once I have the changes, I'll run the grouping script with version 1.5.0 and fill in the template. The notes won't be tagged, published or posted. You'll get them to review, along with any open questions, such as breaking changes with no migration note or malformed lines.