I couldn't find a tracker CSV. The project directory (`/home/dev/project`) has no `.csv` files. It only holds the `release-notes` skill files, which draft release notes and don't cover monthly status reports. A system-wide search for a file with "tracker" in its name found nothing relevant.

Where is the CSV? A path works, or you can paste its contents. It would also help to know:
- **Month:** I'll assume October 2026 unless you say otherwise.
- **Format:** if you have a template or a past report, tell me. Otherwise I'll use a standard layout of summary, completed work, in progress, blockers and risks, and next month.