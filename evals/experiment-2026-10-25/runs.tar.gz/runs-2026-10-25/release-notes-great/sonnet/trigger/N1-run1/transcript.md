# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll check the project for what v2 contains.

## tool call: Bash
```
{"command": "ls -la && cat README* CHANGELOG* package.json 2>/dev/null | head -150", "description": "List project files and read README/changelog"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:02 .
drwxr-xr-x 6 root root 4096 Oct 25 20:02 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:02 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:02 skills
```

## tool call: Bash
```
{"command": "find .claude skills -type f | head -50", "description": "List files in .claude and skills"}
```

## tool result
```
skills/release-notes/scripts/group_changes.py
.claude/skills/release-notes/SKILL.md
.claude/skills/release-notes/scripts/group_changes.py
skills/release-notes/templates/notes.md
.claude/skills/release-notes/templates/notes.md
```

## tool call: Bash
```
{"command": "cat .claude/skills/release-notes/SKILL.md .claude/skills/release-notes/templates/notes.md", "description": "Read release-notes skill and template"}
```

## tool result
```
---
name: release-notes
description: Drafts release notes for one version from a git log export or a list of merged changes. Use when the user asks for release notes, a changelog entry, "what's new in" a version, or notes for a version bump or tag.
---

# Release notes

Turns the commits between two tags into the release notes users read on the releases page.

Not for: marketing announcements or blog posts, security advisories (those need a CVE, affected versions and a disclosure process), or summarizing a single pull request. Say so and stop if that is the request.

## Gotchas

- **A revert cancels an earlier entry.** `Revert "feat: x"` or `revert: feat: x` means neither line ships. The script pairs them and lists the pair under `reverted`. If a revert's target isn't in the range, it undo …[truncated]
```
