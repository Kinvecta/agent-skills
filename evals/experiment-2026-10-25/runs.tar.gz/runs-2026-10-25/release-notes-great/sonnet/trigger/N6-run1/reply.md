I couldn't find a `package.json` in `/home/dev/project`. A recursive search, skipping `node_modules`, also found none. I haven't changed anything.

Is the project in a different directory? If it is, give me the path. If you want a new `package.json` with version 1.5.0, I can create that instead.