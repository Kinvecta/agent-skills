I couldn't bump the version because there's no `package.json` in `/home/dev/project`. The directory only contains `.claude` and `skills`, and a search found no `package.json` anywhere under it.

If the file lives somewhere else, tell me the path and I'll update it to 1.5.0. If you want me to create a new `package.json` in this directory, say so.