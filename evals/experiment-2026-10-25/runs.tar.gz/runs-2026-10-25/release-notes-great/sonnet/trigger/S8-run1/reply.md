I can't draft the notes yet because I don't have the changes to write them from.

`/home/dev/project` isn't a git repository, so I can't export `git log` for v1.0.0. There's also no changes file in the project. The release-notes skill needs one of these:

1. **A git log export.** Tell me the repo path and the previous tag, and I'll run `git log <previous-tag>..v1.0.0`. If v1.0.0 is the first release, I'll use the full history instead.
2. **A file or pasted text** with the commits or merged PRs in this release.

Once I have the changes, I'll group them with the skill's script and draft the notes under the header `1.0.0`. I won't tag or publish anything.