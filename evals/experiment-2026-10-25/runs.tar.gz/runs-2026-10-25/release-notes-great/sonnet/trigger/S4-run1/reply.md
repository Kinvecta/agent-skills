I can't draft the 1.5.0 notes yet because I don't have a change list. `/home/dev/project` isn't a git repository, so there's no history to export, and I found no `changes.txt` or similar file in it. The release-notes script and template are in place.

Either of these would work:

1. **A git log export.** From the real repo, run `git log <previous-tag>..<new-tag> > changes.txt`, then give me the file or paste its contents. Tell me the previous tag if you want me to run it.
2. **A list of the merged changes.** Paste the PR titles or commit subjects, with PR numbers if you have them.

The header will read `1.5.0`, as you gave it. I'll run the grouping script and fill in the template. Any problems or breaking changes with no migration note will come back as questions under the draft. I won't tag or publish anything.