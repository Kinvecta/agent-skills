I can't write the 0.9.0 entry yet because I don't have the commits. Your message says "these commits", but nothing came through with it. The project also isn't a git repo, and there's no `CHANGELOG.md` or exported log file in it.

Could you do one of these?
- Paste the commits or the merged-change list into the chat.
- Point me to a file that has them, such as the output of `git log <previous-tag>..<new-tag>`.
- Give me the two tags and the repo path, if the history lives elsewhere.

Two other things to settle:
- **Version:** I'll use `0.9.0` as the header unless you say otherwise.
- **Changelog:** `CHANGELOG.md` doesn't exist yet. I'll create it with the 0.9.0 entry unless you meant a different path.

Once I have the commits, I'll group them with the skill's script and draft the entry.