# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes", "args": "2.0.0"}
```

## tool result
```
Launching skill: release-notes
```

## assistant
The git log didn't come through. Your message ended after "git log is pasted below", with nothing after it. This directory also isn't a git repository, so I can't export the log myself.

Can you do one of these?
- Paste the log again (the output of `git log <previous-tag>..<new-tag>`).
- Give me the path to a file that contains it.

Once I have it, I'll group the changes with the release-notes script and draft the 2.0.0 entry. I'll use 2.0.0 as the header version.
