I can't write the release notes yet because I don't have the git log. Your message didn't include one, and the project directory has no log export or `changes.txt`. It also isn't a git repository, so I can't run `git log` myself.

I need two things from you:

1. **The changes.** Either paste the git log here, give me the path to a file that contains it, or point me to the repo with the two tags to compare (for example `v1.2.0..v1.3.0`).
2. **The version.** I need the version number for the header, such as `1.3.0`. I won't pick one myself.

Once I have both, I'll group the changes with the release-notes script and fill in the template. I'll list any open questions under the draft.