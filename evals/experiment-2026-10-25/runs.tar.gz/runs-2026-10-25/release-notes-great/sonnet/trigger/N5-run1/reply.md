I don't know which change you mean, and `/home/dev/project` isn't a git repository, so I can't check a diff. Under semver, the rule is:

- **Patch** (x.y.**Z**): backward-compatible bug fixes only, with no new public behavior. This includes internal refactors, docs and dependency bumps that don't change the API.
- **Minor** (x.**Y**.0): backward-compatible new functionality. This includes a new feature, option, endpoint or export, and deprecating something without removing it.
- **Major**: any breaking change to the public API or behavior.

If the change adds anything users can newly do, make it a minor. If it only fixes something that was already supposed to work, make it a patch.

If you tell me what changed, or paste the change list, I'll give you a specific answer. If the project is versioned somewhere else, point me to it and I'll read the diff there.