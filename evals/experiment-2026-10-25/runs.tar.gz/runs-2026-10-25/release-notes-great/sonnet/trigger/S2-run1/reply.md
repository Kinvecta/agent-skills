The git log didn't come through. Your message ended after "git log is pasted below", and there was nothing under it. The project directory isn't a git repository, so I can't pull the log myself.

Could you paste it again? A plain `git log --oneline v1.x.x..HEAD` works, where `v1.x.x` is the previous release tag. If you want PR numbers or authors in the entry, include those too.

Since this is a 2.0.0 release, please also tell me which changes are breaking, if the log doesn't make that clear. I'll put those in their own section with migration notes.