I can't write this advisory yet because the project has no information about the vulnerability. `/home/dev/project` isn't a git repo and contains no source code, changelog, or commit history. It only has the `release-notes` skill files, and none of them mention 1.4.1 or an auth bypass.

An advisory needs accurate facts, and I don't want to guess at them. Please send me any of these:

- **The fix itself:** a commit, diff, or PR for 1.4.1, or the repo path if it lives somewhere else.
- **Vulnerability details:** the affected component and endpoint, the root cause, how the bypass works, and what an attacker gains.
- **Versions:** the first affected version, which I'm assuming is anything before 1.4.1, and the patched version.
- **Severity:** a CVSS vector or score and a CVE or GHSA ID if you have them, or I can propose a score for you to check.
- **Mitigations and credit:** any workarounds available before upgrading, who reported it, and your disclosure timeline.

Once I have those, I'll write the advisory in GitHub Security Advisory format: summary, impact, affected and patched versions, severity, workarounds, remediation, credits, and references. It won't include a working exploit. I'll keep the technical description detailed enough for users to assess their exposure.