I can't write an accurate tweet yet because the project has no release details. It isn't a git repo, and it has no changelog, version file, or source code. The only files are the `release-notes` skill and its templates.

Could you give me any of these?
- The product name and version number
- The 2–4 headline changes or features
- A link to include, such as release notes or a download page
- The tone you want (excited, understated, technical) and any hashtags or handles

If you have a git log or a list of merged changes, paste it in. I can run the release-notes skill first and then write the tweet from the result.

Here's a placeholder draft you can edit:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Notable fix]
>
> Details: [link]