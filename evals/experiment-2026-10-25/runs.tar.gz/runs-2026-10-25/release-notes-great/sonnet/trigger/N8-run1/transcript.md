# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll check the project for release details first.

## tool call: Bash
```
{"command": "ls -la && cat package.json pyproject.toml Cargo.toml CHANGELOG* 2>/dev/null | head -60", "description": "List project files and show version/changelog info"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:02 .
drwxr-xr-x 6 root root 4096 Oct 25 20:02 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:02 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:02 skills
```

## tool call: Bash
```
{"command": "find .claude skills -type f | head -50", "description": "List files in .claude and skills"}
```

## tool result
```
skills/release-notes/scripts/group_changes.py
.claude/skills/release-notes/SKILL.md
.claude/skills/release-notes/scripts/group_changes.py
skills/release-notes/templates/notes.md
.claude/skills/release-notes/templates/notes.md
```

## assistant
I can't write an accurate tweet yet because the project has no release details. It isn't a git repo, and it has no changelog, version file, or source code. The only files are the `release-notes` skill and its templates.

Could you give me any of these?
- The product name and version number
- The 2–4 headline changes or features
- A link to include, such as release notes or a download page
- The tone you want (excited, understated, technical) and any hashtags or handles

If you have a git log or a list of merged changes, paste it in. I can run the release-notes skill first and then write the tweet from the result.

Here's a placeholder draft you can edit:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Notable fix]
>
> Details: [link]
