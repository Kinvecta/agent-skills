I can't draft the 3.1 notes yet because the list of merged PRs didn't come through. Your message ended after "Here are the merged PRs since the last tag", with nothing attached. `/home/dev/project` isn't a git repository, and I found no changes file or changelog in it.

Either of these would work:

1. **Paste the list or attach a file.** A `git log` export or a list of PR titles with numbers is enough.
2. **Give me the previous tag and the repo.** I'd run `git log <previous-tag>..<new-tag>`, which needs a checkout of the repo.

I'll use 3.1 as the header version. Once I have the changes, I'll run them through the grouping script and return the notes with any open questions.