I can't draft the 3.1 notes yet. Your message says the merged PRs are included, but nothing came through. There's also no change list in `/home/dev/project`, and the directory isn't a git repo, so I can't run `git log` here.

I need one of these:

1. **Paste the PR list or commit log** since the last tag. Titles are enough, and PR numbers and any `BREAKING CHANGE` footers help.
2. **Give me a file path** to an exported log, for example the output of `git log <previous-tag>..<new-tag>`.
3. **Point me to the repo and the two tags** if it lives somewhere else on this machine.

I'll use `3.1` as the header version unless you tell me the tag is something different, like `3.1.0`. Once I have the list, I'll group it with the release-notes script and fill in the template. I'll flag any breaking changes that lack a migration note, and any reverts or malformed lines, as questions for you.