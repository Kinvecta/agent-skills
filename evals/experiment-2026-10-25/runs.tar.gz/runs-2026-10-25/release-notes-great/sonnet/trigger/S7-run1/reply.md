I can't update the changelog yet. Your message says "using these commits", but no commits came through. I also found nothing to work from in `/home/dev/project`:

- It isn't a git repository, so I can't run `git log` for a tag range.
- There's no `CHANGELOG.md` to update, and no exported commit list. The only files are the release-notes skill's script and template.

Please send one of these:
1. The commits pasted straight into the chat, or a file path to an export of them.
2. The path to the repo, plus the previous tag and the new tag, so I can export the log myself.

Two other questions:
- **Version:** I'll use 0.9.0 as the header.
- **New file:** Should I create `CHANGELOG.md` in `/home/dev/project`, or is the existing one in another directory?

Once I have the commits, I'll run them through the grouping script and write the 0.9.0 entry. I'll list any open questions under the draft.