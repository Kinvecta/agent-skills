## 2.0.0 (YYYY-MM-DD)

This release moves configuration to `tidy.toml` and drops Python 3.9. It also fixes the exit code when a file is missing.

### Breaking changes

- **Settings are now read from `tidy.toml`.** `tidy.ini` is no longer read. To upgrade: rename `tidy.ini` to `tidy.toml` and run `tidy config migrate` once. (#152)
- **Python 3.9 is no longer supported.** (#146)

### Fixes

- The CLI now exits with code 1, not 0, when a file is missing. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

## Open questions

1. **Release date:** the log doesn't give one, so I left a placeholder. What date should go in the header?
2. **Python 3.9 migration step:** the entry has no migration note. Should users be told to upgrade to Python 3.10 or later, or is there other guidance? I haven't filled one in.
3. **Pagination feature (line 51):** `feat(api add pagination to list endpoint (#148)` has a malformed scope, with a missing `)`. I left it out, so the Features section is empty. Is it a feature that should ship in 2.0.0, as "pagination on the list endpoint (#148)"? If so, Lee Chen would also join the contributors.
4. **Type of the Python 3.9 commit:** it is tagged `fix!:`, but dropping a Python version reads more like a chore or breaking change than a fix. I treated it as breaking, per the `!`.

Not included:
- "add bulk delete endpoint" (#151) was added and then reverted in this range, so it doesn't ship.
- I dropped 2 dependency updates and 1 merge commit.

I haven't tagged or published anything.