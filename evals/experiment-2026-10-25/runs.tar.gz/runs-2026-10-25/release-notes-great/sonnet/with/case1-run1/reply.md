## 1.4.0 (release date: to be confirmed)

This release adds CSV export and upload progress feedback. It also fixes two bugs, one in sync and one in config paths.

### Features

- The `export` command can now write CSV with `--format csv` (#142).
- Uploads over 10 MB now show a progress bar (#138).

### Fixes

- Sync now retries once when the server returns a 503 (#140).
- Config file paths that contain spaces are no longer split (#137).

### Other changes

- Docs: the README now documents the `export` command (#135).
- Performance: the search index is now built in one pass (#134).

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**
- **Release date:** the log doesn't state one, and the template needs it. The newest commit is dated 2026-10-19. What date should the header use?

The script reported no breaking changes, reverts or problems. It dropped 2 commits as noise (1 chore, 1 ci). I haven't tagged or published anything.