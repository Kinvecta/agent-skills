## 1.4.0 (YYYY-MM-DD)

This release adds CSV export and upload progress feedback. It also fixes a sync retry problem and a config path bug.

### Features

- The `export` command can now write CSV with `--format csv`. (#142)
- Uploads over 10 MB now show a progress bar. (#138)

### Fixes

- Sync now retries once when the server returns a 503. (#140)
- Config file paths that contain spaces are no longer split. (#137)

### Other changes

- Docs: the README now documents the `export` command. (#135)
- Performance: the search index is built in a single pass. (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

- **Release date:** the log doesn't give one. The latest commit is dated 2026-10-19, but I didn't want to guess the tag date. What should the header say?
- Nothing else needs your input. There are no breaking changes, reverts or malformed entries. One chore and one CI commit were dropped as noise.