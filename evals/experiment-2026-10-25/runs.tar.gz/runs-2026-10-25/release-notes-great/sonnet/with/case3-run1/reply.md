## 2.0.0 (release date: TBD)

This release moves configuration to `tidy.toml` and drops Python 3.9. It also fixes the exit code for missing files.

### Breaking changes

- Settings are now read from `tidy.toml`, and `tidy.ini` is no longer read. To upgrade: rename `tidy.ini` to `tidy.toml` and run `tidy config migrate` once. (#152)
- Python 3.9 is no longer supported. To upgrade: *(no migration note in the log, see question 2)* (#146)

### Fixes

- The CLI now exits with code 1, not 0, when a file is missing. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

### Open questions

1. **Release date:** The log doesn't give one. What date should go in the header?
2. **Python 3.9 migration step:** Commit 748596a (#146) is marked breaking but has no migration note. What should users do? For example, which Python version is the new minimum? I haven't guessed.
3. **Malformed line:** Line 51 of the log, `feat(api add pagination to list endpoint (#148)`, has a missing `)` in the scope, so I left it out. It looks like a pagination feature, which would be the release's only feature. Can you confirm the intended entry? If so, I'll add a Features section.

### Left out on purpose

- **Reverted:** "add bulk delete endpoint" (#151) was added and then reverted in this range, so it doesn't ship.
- **Dropped:** 2 dependency bumps and 1 merge commit.

I haven't tagged or published anything.