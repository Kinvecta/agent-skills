I've drafted the v2.0.0 notes below. Five questions need answers before they're ready.

---

## 2.0.0 (YYYY-MM-DD)

This major release moves configuration to `tidy.toml`, drops support for Python 3.9, and fixes the exit code the CLI returns when a file is missing.

### Breaking changes

- **Configuration now comes from `tidy.toml`.** `tidy.ini` is no longer read. To upgrade: rename `tidy.ini` to `tidy.toml` and run `tidy config migrate` once. (#152)
- **Python 3.9 is no longer supported.** To upgrade: *(migration step needed, see question 2)* (#146)

### Fixes

- **CLI:** when a file is missing, the CLI now exits with code 1 instead of 0. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date:** what date should go in the header?
2. **Python 3.9 (#146):** the commit is marked breaking but gives no migration note. What should users do? For example: "Upgrade to Python 3.10 or later." Which Python version is now the minimum?
3. **Line 51, `feat(api add pagination to list endpoint (#148)`:** the commit title is malformed (the scope's closing `)` is missing), so I left it out. Is this a real feature that ships in 2.0.0? If so, I'll add it under Features.
4. **Lee Chen** isn't in the contributors list. Their only commits are the bulk delete endpoint, which was reverted, and the malformed pagination commit. If #148 ships, should they be credited?
5. **Features section:** it's empty, so I left it out. If #148 is added it will come back.

**Left out on purpose:**
- **Bulk delete endpoint (#151):** added and then reverted in this same range, so it doesn't ship.
- **Two dependency bumps from bots:** the `requests` 2.32.4 bump and `actions/checkout` v7.
- **One merge commit.**
- **Squash commit sub-bullets in #152:** these are the PR's history, not separate changes.

Nothing has been tagged or published.