I drafted the v2.0.0 notes below. Three things need your answer before they're ready: the release date, a commit the grouping script couldn't read, and a missing upgrade step for dropping Python 3.9.

---

## 2.0.0 (YYYY-MM-DD)

This major release moves configuration to `tidy.toml`, drops Python 3.9, and fixes the CLI's exit code when a file is missing.

### Breaking changes

- **Settings are now read from `tidy.toml`.** `tidy.ini` is no longer read. To upgrade: rename `tidy.ini` to `tidy.toml` and run `tidy config migrate` once. (#152)
- **Python 3.9 is no longer supported.** To upgrade: *[upgrade step needed, see question 3]* (#146)

### Fixes

- **CLI:** tidy now exits with code 1 instead of 0 when a file is missing, so scripts and CI can detect the failure. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

### Open questions

1. **Release date:** what date should the header show? The log doesn't say when 2.0.0 ships.
2. **Commit 96a7b8c (#148) has a broken title:** `feat(api add pagination to list endpoint` is missing the `)`, so the script left it out. Did "add pagination to list endpoint" ship in 2.0.0? If it did, I'll add a Features section for it and add Lee Chen to the contributors.
3. **The Python 3.9 change (#146) has no upgrade step.** It's marked `fix!` with no `BREAKING CHANGE:` note. What should users do: is the new minimum Python 3.10? And should it be labelled a removal rather than a fix?

### Left out on purpose

- **Bulk delete endpoint (#151):** it was added and then reverted in this same range (f1e2d3c), so it doesn't ship.
- **Bot and merge commits:** two dependency bumps (dependabot, renovate) and one merge commit.
- **Commit list inside #152:** the bullets under its title are the PR's own history, not separate changes.

Nothing has been tagged or published.