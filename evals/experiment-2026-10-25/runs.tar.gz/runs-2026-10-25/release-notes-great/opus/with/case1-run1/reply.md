## 1.4.0 (YYYY-MM-DD)

This release adds CSV export and an upload progress bar. It also fixes sync failures on temporary server errors and config paths that contain spaces.

### Features

- **Export:** The export command now takes `--format csv`, so you can export data as CSV. (#142)
- Uploads over 10 MB now show a progress bar. (#138)

### Fixes

- **Sync:** If the server returns a 503, sync now retries once before failing. (#140)
- Config file paths that contain spaces now work. Before, they were split into separate arguments. (#137)

### Other changes

- **Docs:** The README now documents the export command. (#135)
- **Performance:** The search index is now built in one pass. (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date:** The log doesn't say when 1.4.0 ships, so the header has a placeholder. The newest commit is from 2026-10-19. What date should go in the header?
2. **Lee Chen isn't listed as a contributor:** Lee wrote the two commits that were left out of the notes (a version bump in the package metadata and a CI caching change). The script removed Lee from the contributor list along with those commits, but Lee is a person, not a bot. Should Lee be added?

There were no breaking changes, reverts or malformed commit lines. Nothing has been tagged or published.