## 1.4.0 (YYYY-MM-DD)

This release adds CSV export and an upload progress bar. It also makes sync more reliable and fixes config paths that contain spaces.

### Features

- **Export:** You can now export to CSV with `--format csv` on the export command. (#142)
- Uploads over 10 MB now show a progress bar. (#138)

### Fixes

- **Sync:** When the server returns a 503, sync now retries once instead of failing straight away. (#140)
- Config file paths that contain spaces are no longer split into separate arguments. (#137)

### Other changes

- **Docs:** The README now documents the export command. (#135)
- **Performance:** The search index is now built in one pass. (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date:** The log doesn't say when 1.4.0 ships, so the header still has a placeholder. What date should go there?
2. **Lee Chen isn't listed as a contributor.** Their two commits were a version bump and a CI cache change. The grouping script drops those commit types and removes their authors from the contributor list along with them. Lee isn't a bot, so do you want them credited?

The grouping script found no breaking changes, no reverts and no malformed commit lines. I compared its output with the raw log and they match. Nothing has been tagged or published.