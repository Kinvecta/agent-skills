# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Bash
```
{"command": "ls -la && find . -maxdepth 2 -not -path './node_modules*' -not -path './.git*' | head -100", "description": "List project files"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:03 .
drwxr-xr-x 6 root root 4096 Oct 25 20:03 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:03 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:03 skills
.
./skills
./.claude
./skills/release-notes
./.claude/skills
```

## tool call: Bash
```
{"command": "find . -type f | head -50", "description": "List all files in project"}
```

## tool result
```
./.claude/skills/release-notes/SKILL.md
./.claude/skills/release-notes/templates/notes.md
./skills/release-notes/templates/notes.md
./.claude/skills/release-notes/scripts/group_changes.py
./skills/release-notes/scripts/group_changes.py
```

## tool call: Bash
```
{"command": "cat .claude/skills/release-notes/SKILL.md .claude/skills/release-notes/templates/notes.md; diff -r .claude/skills/release-notes skills/release-notes", "description": "Show release-notes skill files"}
```

## tool result
```
---
name: release-notes
description: Drafts release notes for one version from a git log export or a list of merged changes. Use when the user asks for release notes, a changelog entry, "what's new in" a version, or notes for a version bump or tag.
---

# Release notes

Turns the commits between two tags into the release notes users read on the releases page.

Not for: marketing announcements or blog posts, security advisories (those need a CVE, affected versions and a disclosure process), or summarizing a single pull request. Say so and stop if that is the request.

## Gotchas

- **A revert cancels an earlier entry.** `Revert "feat: x"` or `revert: feat: x` means neither line ships. The script pairs them and lists the pair under `reverted`. If a revert's target isn't in the range, it undo …[truncated]
```
