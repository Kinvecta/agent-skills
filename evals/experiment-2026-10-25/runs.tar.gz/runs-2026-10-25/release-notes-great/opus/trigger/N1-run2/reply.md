I can't write this yet. There's nothing in the project about your product or what's in v2. `/home/dev/project` contains only the `release-notes` skill, with no repo, changelog or product docs. That skill also says it isn't meant for blog posts or marketing announcements, so it's not the right tool here either.

I don't want to invent features or claims your customers would read, so I need some details first:

1. **Product name and audience:** what the product is and who reads the blog (developers, business users, admins).
2. **What's in v2:** the main changes. Any of these works:
   - a git log export (`git log v1.x.x..v2.0.0 > changes.txt`) or release notes you already have
   - a rough bullet list of the headline features
3. **Breaking changes and upgrade path:** what customers have to do to move from v1, and whether v1 stays supported (and until when).
4. **Logistics:** the release date, where it's available, and whether pricing or plans change.
5. **Tone and length:** for example, a short friendly post (~500 words) or a longer feature walkthrough. Past posts help if you have any.

If you have a git log, I can run the grouping script on it first to get an accurate list of changes, then turn that into the blog post. That way every claim in the post traces back to a real change.