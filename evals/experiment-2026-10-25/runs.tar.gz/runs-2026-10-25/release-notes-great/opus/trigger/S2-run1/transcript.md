# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
The git log didn't come through. Your message ends after "pasted below," and there's nothing attached. This directory isn't a git repository either, so I can't pull the log myself.

Could you paste it again? Any of these works:
- the raw `git log` output
- `git log --oneline v1.x.x..v2.0.0`, which is easier to scan
- a list of merged PRs

If there's an existing `CHANGELOG.md` you want this entry to match, point me to it or paste a previous entry, and I'll follow its format.
