I couldn't write a commit message because there are no staged changes to read. `/home/dev/project` isn't a git repository: `git status` fails with "not a git repository". The folder holds only a `.claude/` and a `skills/` directory, and I found no `.git` folder anywhere nearby under `/home/dev`.

Any of these would let me write it:

- **Wrong folder:** tell me the path to the repository you meant and I'll read the staged diff there.
- **Repo not set up yet:** run `git init` and `git add …` here, then ask again.
- **Changes are somewhere else:** paste the output of `git diff --staged` and I'll write the message from that.