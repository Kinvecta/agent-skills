I couldn't find anything about the release in this project. `/home/dev/project` isn't a git repo, and it has no changelog, README, or version file. The only thing in it is the `release-notes` skill.

To write the tweet I need a few details:

1. **Product name and version** (e.g. "Acme v2.4")
2. **What's new:** the 1–3 changes you most want to highlight. You can also paste a changelog, a `git log` export, or a list of merged PRs, and I'll pick out the main points.
3. **Link** to the release page, docs or download.
4. **Tone (optional):** playful, straightforward or technical, and whether you want emoji or hashtags.

If you only have raw commits, I can run the `release-notes` skill on them first and write the tweet from the result.