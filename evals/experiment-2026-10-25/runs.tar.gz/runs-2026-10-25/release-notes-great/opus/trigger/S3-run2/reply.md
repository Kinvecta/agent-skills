I can draft the 3.1 notes, but the list of merged PRs didn't come through. Your message ends at "Here are the merged PRs since the last tag" with nothing after it. There's also no change list or git history in `/home/dev/project` I could use instead, since it isn't a git repository.

Any of these would work:

- **Paste the list here**: PR titles, or `git log` output with commit bodies so changes marked as breaking in the body aren't missed.
- **Point me to a file** with the export, e.g. from `git log v3.0..v3.1 > changes.txt`.
- **Give me the path to the repo** and the previous tag, and I'll export the range myself.

Once I have it, I'll write the 3.1 notes and list anything unclear as questions at the end. I won't tag or publish anything.