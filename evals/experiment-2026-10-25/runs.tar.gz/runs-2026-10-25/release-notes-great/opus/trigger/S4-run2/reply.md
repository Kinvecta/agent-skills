I can't draft these yet because there's no change list to work from. `/home/dev/project` isn't a git repository, and it holds only the release-notes skill files. There's no commit log or `changes.txt`.

Send me one of these and I'll write the 1.5.0 notes:

1. **A git log export** of the commits since the last release. From your repo, run:
   ```
   git log <previous-tag>..HEAD > changes.txt
   ```
   Then give me the file path or paste the contents.
2. **The repo path and the previous tag** (for example `v1.4.x`), and I'll export it myself.
3. **A pasted list** of the merged PRs or changes.

Once I have it, the skill's script will group the changes into breaking changes, features, fixes and reverted items. I'll write the notes from that, with the header set to 1.5.0, and list anything unclear as questions. I won't tag or publish anything.