The git log didn't come through. Your message ends right after "pasted below." I also checked the project directory, and it isn't a git repository and has no exported log file in it, so I can't pull the history myself.

Could you paste the log again? Any of these would work:

- `git log --oneline v1.x.x..HEAD` (replace with your last 1.x tag)
- The full `git log` output if you want me to pick up details from the commit bodies
- A list of merged PRs

Once I have it, I'll write the 2.0.0 entry with the breaking changes up front, since this is a major version.