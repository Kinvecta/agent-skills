I couldn't find any staged changes. `/home/dev/project` isn't a git repository, and there's no `.git` directory in it, above it, or anywhere under `/home/dev`. The only things in the folder are a `.claude/` directory and a `skills/` directory.

A few possible fixes:
- **Wrong directory:** give me the path to the repo you're working in and I'll read the staged diff there.
- **Repo is somewhere I can't see,** such as another machine or container: run `git diff --cached` there and paste the output, and I'll write the message from it.
- **Repo hasn't been set up yet:** I can run `git init` here, but you'd still need to stage something before there's anything to describe.