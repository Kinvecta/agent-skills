# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Bash
```
{"command": "ls -la && ls -t | head; for f in CHANGELOG* RELEASE* README* package.json pyproject.toml Cargo.toml; do [ -f \"$f\" ] && { echo \"== $f\"; head -60 \"$f\"; }; done", "description": "List project files and show release-related docs"}
```

## tool result
```
Exit code 1
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:04 .
drwxr-xr-x 6 root root 4096 Oct 25 20:04 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:04 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:04 skills
skills
```

## tool call: Bash
```
{"command": "find . -type f | head -50", "description": "List all files in the project"}
```

## tool result
```
./.claude/skills/release-notes/SKILL.md
./.claude/skills/release-notes/templates/notes.md
./skills/release-notes/templates/notes.md
./.claude/skills/release-notes/scripts/group_changes.py
./skills/release-notes/scripts/group_changes.py
```

## tool call: Bash
```
{"command": "cat .claude/skills/release-notes/templates/notes.md; head -30 .claude/skills/release-notes/SKILL.md", "description": "Show release-notes template and skill header"}
```

## tool result
```
## {version} ({release date, YYYY-MM-DD})

{one or two sentences: what this release is for, in plain words. No hype.}

### Breaking changes

{one bullet per entry in "breaking": what changed, then "To upgrade:" and the migration step from breaking_note, then (#PR). Leave this section out if the list is empty.}

### Features

{one bullet per entry in "features": the description rewritten for a user, then (#PR) if the JSON has one}

### Fixes

{one bullet per entry in "fixes", same form}

### Other changes

{one bullet per entry in "other" (docs, performance, refactors that users notice). Leave out if empty.}

### Contributors

{the names in "contributors", comma-separated. Leave out if empty.}
---
name: release-notes
description: Drafts release notes for one version from a git log export or …[truncated]
```
