I can't draft the 1.2.1 notes yet because the list of fixes didn't come through with your message. I checked the project folder and there's no change list file there, and it isn't a git repo, so I can't export one from tags either.

Any of these would work:
- **Paste the list** of fixes or commit messages here.
- **Give me a file path** to a change list or a `git log` export.
- **Name the two tags** (for example `v1.2.0..v1.2.1`) and the repo path, and I'll export the log myself.

Once I have it, I'll group the changes, write the notes for 1.2.1, and list any unclear entries as questions. I won't publish or tag anything.