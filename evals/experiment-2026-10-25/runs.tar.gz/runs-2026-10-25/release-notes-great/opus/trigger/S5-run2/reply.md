I can't find a git log to work from. Nothing was pasted into your message, there's no log file in `/home/dev/project`, and the folder isn't a git repository, so I can't export one myself.

To write the notes I need two things:

1. **The change list**, in any of these forms:
   - paste the `git log` output here
   - give me the path to a file that has it
   - point me to the repo and the two tags (for example `v1.3.0..v1.4.0`), and I'll export it
2. **The version number** for the release header, such as `1.4.0`. I use exactly what you give me and won't pick the next number myself.

Once I have those, I'll group the changes with the release-notes script and give you a Markdown draft, plus any questions about unclear commits or breaking changes that have no migration note. I won't tag or publish anything.