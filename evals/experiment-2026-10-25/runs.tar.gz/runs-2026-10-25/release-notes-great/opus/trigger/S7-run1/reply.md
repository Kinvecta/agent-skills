There's no commit list for me to use: you didn't paste one, `/home/dev/project` isn't a git repository (so I can't run `git log <prev-tag>..<new-tag>`), and there's no `CHANGELOG.md` there yet. The only things in the folder are `.claude/` and `skills/`.

To write the 0.9.0 entry, please do one of these:

1. **Paste the commits** here, or give me the path to a file with them (for example the output of `git log v0.8.x..v0.9.0 > changes.txt` from the actual repo).
2. **Point me to the repo** if it's somewhere else on this machine, along with the previous tag.

Also, is there an existing `CHANGELOG.md` somewhere that I should add to? If not, I'll create one in `/home/dev/project` with 0.9.0 as the first entry.

Once I have the commits, I'll run them through the skill's grouping script, write the entry from its template, and list any open questions (for example, breaking changes that have no migration note).