# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes", "args": "3.1"}
```

## tool result
```
Launching skill: release-notes
```

## tool call: Bash
```
{"command": "ls -la; git tag 2>/dev/null | tail", "description": "List project files and git tags"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:03 .
drwxr-xr-x 6 root root 4096 Oct 25 20:03 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:03 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:03 skills
```

## assistant
I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends at "Here are the merged PRs since the last tag" with nothing after it. I also checked the project directory: there's no changes file, and it isn't a git repo, so I can't export the log from tags.

Could you send one of these?

- **Paste the list** of merged PRs or the `git log` output here.
- **Give a file path** to a saved export, such as `changes.txt`.
- **Give a repo path and the previous tag**, so I can run `git log <previous-tag>..v3.1` myself.

Once I have it, I'll group the changes with the release-notes script and draft the notes. They'll be headed **3.1**, with breaking changes first. I'll list any questions under the draft, and I won't publish anything.
