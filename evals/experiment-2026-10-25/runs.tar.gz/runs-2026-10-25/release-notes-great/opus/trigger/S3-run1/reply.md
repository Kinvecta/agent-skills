I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends at "Here are the merged PRs since the last tag" with nothing after it. I also checked the project directory: there's no changes file, and it isn't a git repo, so I can't export the log from tags.

Could you send one of these?

- **Paste the list** of merged PRs or the `git log` output here.
- **Give a file path** to a saved export, such as `changes.txt`.
- **Give a repo path and the previous tag**, so I can run `git log <previous-tag>..v3.1` myself.

Once I have it, I'll group the changes with the release-notes script and draft the notes. They'll be headed **3.1**, with breaking changes first. I'll list any questions under the draft, and I won't publish anything.