## 2.0.0 (YYYY-MM-DD)

This is a major release. It changes the config file format and drops Python 3.9, so read the breaking changes before upgrading.

### Breaking changes

- **Config is read from `tidy.toml` instead of `tidy.ini`.** `tidy.ini` is no longer read. To upgrade: rename `tidy.ini` to `tidy.toml`, then run `tidy config migrate` once. (#152)
- **Python 3.9 is no longer supported.** To upgrade: _[migration step needed: which Python version to move to]_. (#146)

### Fixes

- The CLI now exits with code 1 (it used to exit with 0) when a file is missing. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

## Open questions

1. **Release date.** The header needs the release date. I left it as `YYYY-MM-DD`.
2. **Python 3.9 migration step.** The commit (`fix!: drop support for Python 3.9 (#146)`) has no migration note, so I don't know which Python version users should move to. Please give me the minimum version.
3. **Malformed commit, line 51.** `feat(api add pagination to list endpoint (#148)` is missing the closing `)` after the scope. The script couldn't read its type, so I left it out. If pagination ships in 2.0.0, I need the correct title, and it should be added under Features. Lee Chen's only other commit in this range is the reverted one, so Lee isn't in the contributors list. If pagination ships, Lee should be added.
4. **Exit-code change (#149).** It's labeled `fix`, but scripts that check the exit code will see different behavior. You may want to flag it as breaking. I left it under Fixes.

## Left out on purpose

- **Reverted:** `feat(api): add bulk delete endpoint (#151)` was reverted in f1e2d3c. Neither the feature nor the revert appears in the notes. The original commit is in this range, so the revert cancels an entry that would otherwise ship.
- **Dropped as noise:** 2 dependency bumps (dependabot, renovate) and 1 merge commit.