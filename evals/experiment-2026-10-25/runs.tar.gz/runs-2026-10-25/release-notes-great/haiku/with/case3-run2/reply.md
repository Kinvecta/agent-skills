## 2.0.0 (YYYY-MM-DD)

This release changes how config files are read and drops Python 3.9. It also fixes the exit code when a file is missing.

### Breaking changes

- **Config is now read from `tidy.toml`.** `tidy.ini` is no longer read.
  - To upgrade: rename `tidy.ini` to `tidy.toml`, then run `tidy config migrate` once. (#152)
- **Python 3.9 is no longer supported.** (#146)
  - To upgrade: _[question: what should users on 3.9 do? The commit has no migration note.]_

### Fixes

- The CLI now exits with code 1 (not 0) when a file is missing. (#149)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date.** The header needs the tag's date. Today is 2026-10-25, but I didn't use it because the release date may differ.
2. **Python 3.9 upgrade step.** Commit `748596a` is marked `fix!:` (breaking) but has no migration note. What should 3.9 users do? Is there a minimum version to move to?
3. **Malformed commit left out.** Line 51 of `git-log-tricky.txt` (`feat(api add pagination to list endpoint (#148)`) is missing a closing parenthesis and has no type separator. The script left it out. If pagination shipped in 2.0.0, please confirm the intended wording and I'll add it under Features. This commit was by Lee Chen, who is also not in the contributors list for the same reason. Should Lee be credited?
4. **Reverted change.** "add bulk delete endpoint (#151)" was reverted by `f1e2d3c` in the same range, so it's excluded. Confirm that the revert is meant to ship.

I left out the Features and Other changes sections because they're empty. I also dropped two dependency bumps and one merge commit as noise, and two bot commits (dependabot, renovate) are not credited.