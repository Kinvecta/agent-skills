## 1.4.0 (2026-10-25)

This release adds CSV export, a progress bar for large uploads, and fixes for sync retries and config file paths.

### Features

- Export now supports CSV: `--format csv` is available on the export command. (#142)
- Uploads over 10 MB show a progress bar. (#138)

### Fixes

- Sync retries once when the server responds with 503 instead of failing immediately. (#140)
- Config file paths containing spaces are no longer split into separate arguments. (#137)

### Other changes

- The export command is now documented in the README. (#135)
- The search index is built in a single pass, which is faster. (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date:** I used today's date (2026-10-25) because the log has no tag date. The most recent commit is from 2026-10-19. Please confirm the date you want in the header.
2. **Upload progress bar:** The commit doesn't say whether the bar appears in the CLI, the web UI, or both. The entry is written without that detail; add it if users need to know.

Nothing was reverted, there are no breaking changes, and the script reported no problems with the log. The grouping came from `group_changes.py` and the draft follows `templates/notes.md`. I did not tag or publish anything.