## 1.4.0 (2026-10-25)

This release adds CSV export and an upload progress bar, and fixes sync retries and config paths that contain spaces.

### Features

- The export command now accepts `--format csv` (#142)
- Uploads larger than 10 MB show a progress bar (#138)

### Fixes

- Sync retries once when the server returns 503 (#140)
- Config file paths containing spaces are no longer split (#137)

### Other changes

- The export command is documented in the README (#135)
- The search index is built in a single pass (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open questions**

1. **Release date:** The template needs a date and the log doesn't give one. I used 2026-10-25 (today). Please confirm or give the tag date.
2. **Lee Chen:** Lee Chen authored two commits in this range (`chore: bump version in package metadata` and `ci: cache pip downloads in the test workflow`). Both were dropped as non-user-facing, so Lee isn't in the contributors list. Should Lee be credited anyway?

**Checks:** No breaking changes, reverts, or parse problems were reported. All 6 listed entries appear once, the PR numbers match the script output, the version matches the argument, and there are no bot contributors.