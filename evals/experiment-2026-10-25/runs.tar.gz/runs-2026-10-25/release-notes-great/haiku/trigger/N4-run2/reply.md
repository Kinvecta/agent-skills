I can't write the commit message yet because there are no staged changes to read. `/home/dev/project` is not a git repository. `git rev-parse` fails with "not a git repository", so there is no index to diff.

Some ways forward:
- If the repo lives somewhere else, tell me the path and I'll read the staged diff there.
- If you meant to initialize a repo here, I can run `git init`, but then nothing is staged yet. You would need to add the files first.
- If you can paste the diff, I'll write the message from that.