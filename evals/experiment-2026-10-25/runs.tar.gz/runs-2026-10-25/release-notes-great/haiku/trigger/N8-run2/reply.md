I couldn't find anything about the release in this project. `/home/dev/project` has no changelog, README, package file, or git history. It only contains `.claude/` and `skills/` folders with release-notes templates.

To write the tweet I need to know:
- **What the release is called** (product or version number)
- **The 1–3 changes people will care about most**
- **Any link** to include, and whether you want a particular tone (playful, technical, announcement-style)

If you paste the release notes or changelog here, I'll turn them into a tweet under 280 characters. Here's a placeholder to show the shape:

> Just shipped [Product] v[X.Y]! 🚀 [Headline feature] so you can [benefit]. Also: [second improvement]. Try it now: [link]