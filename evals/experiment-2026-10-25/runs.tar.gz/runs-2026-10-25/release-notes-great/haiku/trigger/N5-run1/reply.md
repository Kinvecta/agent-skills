I can't tell yet. This directory has no version file, changelog, or git history, and no code changes for me to review. The answer depends on what changed since the last release:

- **Major (X.0.0):** the change breaks existing users, such as removing or renaming a public API, changing a return type, or changing a default behavior they rely on.
- **Minor (x.Y.0):** the change adds backward-compatible functionality, such as a new command, option, or endpoint, or a deprecation with the old path still working.
- **Patch (x.y.Z):** the change is backward-compatible bug fixes, performance work, or internal refactors with no new public behavior.

If you're on 0.x, many projects treat breaking changes as a minor bump instead of a major one.

If you tell me what changed, or point me to the repo or the list of merged changes, I'll pick the bump and explain why. If it's a git repo, I can also review the diff since the last tag.