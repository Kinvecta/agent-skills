I couldn't find anything about the release in `/home/dev/project`. It has no changelog, README, or git history, only a `release-notes` skill folder. I don't want to invent features, so I need a few details from you:

1. **Product name** and what the release does, in a sentence or two.
2. **The headline change**, or the two or three most important ones.
3. **A link** to share (docs, changelog, or download page), if you want one in the tweet.
4. **Tone**: playful, technical, or announcement-style.
5. **Version number**, if it should appear.

If you paste the release notes or the list of merged changes, I can write the tweet from those. I can also keep it under 280 characters and give you a couple of variants.