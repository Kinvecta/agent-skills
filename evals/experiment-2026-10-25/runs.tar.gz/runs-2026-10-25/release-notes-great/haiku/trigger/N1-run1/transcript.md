# session
model: claude-haiku-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll check the project for details on v2 before drafting.

## tool call: Bash
```
{"command": "ls -la && find . -maxdepth 2 -not -path '*/node_modules*' -not -path '*/.git/*' \\( -iname '*change*' -o -iname '*release*' -o -iname '*readme*' -o -iname '*v2*' -o -iname '*blog*' -o -iname 'package.json' -o -iname '*roadmap*' -o -iname '*migrat*' \\) 2>/dev/null | head -50", "description": "List project files and find release-related docs"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:00 .
drwxr-xr-x 6 root root 4096 Oct 25 20:00 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:00 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:00 skills
./skills/release-notes
```

## tool call: Bash
```
{"command": "find . -type f | head -100 && echo --- && cat .claude/settings*.json 2>/dev/null; find .claude -type f | head; echo ---; find skills -type f -exec sh -c 'echo \"== $1\"; cat \"$1\"' _ {} \\;", "description": "List all project files and read the release-notes skill"}
```

## tool result
```
./skills/release-notes/scripts/group_changes.py
./skills/release-notes/templates/notes.md
./.claude/skills/release-notes/SKILL.md
./.claude/skills/release-notes/templates/notes.md
./.claude/skills/release-notes/scripts/group_changes.py
---
.claude/skills/release-notes/SKILL.md
.claude/skills/release-notes/scripts/group_changes.py
.claude/skills/release-notes/templates/notes.md
---
== skills/release-notes/templates/notes.md
## {version} ({release date, YYYY-MM-DD})

{one or two sentences: what this release is for, in plain words. No hype.}

### Breaking changes

{one bullet per entry in "breaking": what changed, then "To upgrade:" and the migration step from breaking_note, then (#PR). Leave this section out if the list is empty.}

### Features

{one bullet per entry in "features": the descr …[truncated]
```

## assistant
I couldn't find anything about v2 in this project. It has no changelog, README, git history, or product docs. It only contains a release-notes skill. So I've written a draft with placeholders for the product-specific facts rather than inventing features.

---

# Introducing [Product] v2: [one-line promise, e.g., "faster, simpler, and built around what you asked for"]

*[Month DD, 2026]*

Today we're releasing [Product] v2. [Two sentences on why this release exists: the problem customers kept raising, and what v2 changes at a high level.]

## What's new

**[Headline feature 1].** [What it does, in terms of what the customer can now do. One or two sentences. Include a concrete example if you have one.]

**[Headline feature 2].** [Same form.]

**[Headline feature 3].** [Same form.]

## Performance and reliability

[Only include this section if you have measured results. For example: "Pages load [X]% faster on average, based on [how it was measured]." If you don't have numbers, cut the section.]

## Breaking changes and upgrading

v2 includes changes that affect existing integrations. Please review these before upgrading:

- **[Change 1]:** [What changed.] To upgrade, [migration step].
- **[Change 2]:** [What changed.] To upgrade, [migration step].

We've written a full upgrade guide at [link]. [If v1 support has an end date, state it here.]

## Getting started

- **Existing customers:** [Upgrade path. Is it automatic, opt-in, or a manual step?]
- **New customers:** [Link to sign-up or docs.]
- **Questions:** [Support channel or contact.]

## Thank you

[One or two sentences thanking customers, ideally referencing feedback that shaped v2. Only name customers if they've agreed to be named.]

---

**What I need to finish this:**

1. **The change list.** Either a changelog, a `git log v1.x.0..v2.0.0` export, or a list of merged PRs. I can run the `release-notes` skill on it to sort changes into features, fixes, and breaking changes, and then fill in the sections above.
2. **Product name, launch date, and tone.** Tell me whether you want it formal or casual.
3. **Breaking changes and migration steps.** These need to be accurate, so please confirm them with the engineering team.
4. **Any customer quotes or metrics**, with permission to publish them.

Once I have the change list, I can fill in the draft. Please review it before publishing, since this is outward-facing and the claims need to match what shipped.
