I can't summarize the PR yet because I can't find any PR code here. `/home/dev/project` isn't a git repository. It contains only a `release-notes` skill with its template and a `group_changes.py` script, under both `.claude/skills/` and `skills/`, and no source changes. `gh pr view` also returned nothing, since there's no repo context.

To get the summary, tell me one of these:

- **The repo location** (path to the clone), so I can run `git diff` against the base branch.
- **The PR number or URL**, plus the repo if it isn't the current one. I'll fetch the title, description, and diff with `gh`.
- **The branch name**, if the changes are on a branch in a clone I can reach.

Once I have the diff, I'll write the summary for the reviewer: what changed, why, the files touched, anything risky or untested, and what they should look at first.