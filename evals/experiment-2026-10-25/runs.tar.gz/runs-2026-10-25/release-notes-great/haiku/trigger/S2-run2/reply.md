I can't find the git log. Your message doesn't include it, and the project directory (`/home/dev/project`) isn't a git repository and has no log or changelog file.

Could you paste the output of `git log` for the range leading up to 2.0.0? For example, `git log <previous-tag>..<new-tag>`, or the full log if this is the first release. If you'd rather save it to a file, give me the path. A squash-merge body and a `BREAKING CHANGE:` footer, if present, are both worth including.

Once I have it, I'll group the changes with the release-notes script and draft the 2.0.0 entry. I'll also list any breaking changes that lack a migration note as questions for you.