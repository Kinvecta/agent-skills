I can't produce this summary yet because there's no git history here to read.

- `/home/dev/project` is not a git repository. It only contains `.claude/` and `skills/`.
- I searched the filesystem-level project paths for a git log export or changelog for this project and found nothing relevant. The hits were unrelated third-party files.

To get the summary, I need one of these:

1. **Path to the repository** that contains the `v2.3.0` and `v2.4.0` tags. I'll run `git log v2.3.0..v2.4.0` there.
2. **A git log export** saved to a file, for example from `git log v2.3.0..v2.4.0 --pretty=format:'%h %s (%an)'`. Give me the file path.
3. **A list of merged changes** pasted into the chat.

Once I have the commits, I'll group them into features, fixes, and other changes, and write the summary for the releases page. I can use the `release-notes` skill for that step.