I can't summarize a PR from here yet. `/home/dev/project` isn't a git repository, and `gh pr view` finds nothing because there's no checkout to resolve a PR from. The directory only holds release-notes skill files (`skills/release-notes/` and `.claude/skills/release-notes/`), with no source code or diff.

To proceed, I need one of these:

1. **The PR number or URL** (e.g. `owner/repo#123`). I can fetch it with `gh pr view <n> --json title,body,files,commits` and `gh pr diff <n>`, without a local checkout.
2. **The repo checked out locally**, in which case I'll run from that directory so `gh pr view` can resolve the current branch.
3. **The diff or commit list pasted here.**

Once I have the PR, I'll write a reviewer-oriented summary covering what changed, why, the files and areas touched, risk spots, and what to check first.