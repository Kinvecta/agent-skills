# session
model: claude-haiku-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
It depends on what the change does, and I can't see that yet. This directory isn't a git repo, so I have no diff to inspect.

Under semantic versioning:

- **Patch (x.y.Z):** backward-compatible bug fixes, including small internal fixes that don't change the public interface.
- **Minor (x.Y.0):** backward-compatible new features, new public functions or options, or deprecations (with the old behavior still working).
- **Major (X.0.0):** breaking changes, such as removed or renamed public APIs, changed defaults, or changed behavior that existing callers rely on.

If you tell me what changed, or point me to the diff, a changelog, or the commits, I'll pick the version. If the project has a `package.json`, `pyproject.toml`, or changelog, I can also check the current version and suggest the next one.
