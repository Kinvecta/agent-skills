It depends on what the change does, and I can't see that yet. This directory isn't a git repo, so I have no diff to inspect.

Under semantic versioning:

- **Patch (x.y.Z):** backward-compatible bug fixes, including small internal fixes that don't change the public interface.
- **Minor (x.Y.0):** backward-compatible new features, new public functions or options, or deprecations (with the old behavior still working).
- **Major (X.0.0):** breaking changes, such as removed or renamed public APIs, changed defaults, or changed behavior that existing callers rely on.

If you tell me what changed, or point me to the diff, a changelog, or the commits, I'll pick the version. If the project has a `package.json`, `pyproject.toml`, or changelog, I can also check the current version and suggest the next one.