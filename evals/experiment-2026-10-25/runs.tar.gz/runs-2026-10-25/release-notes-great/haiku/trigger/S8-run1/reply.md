I can't draft the v1.0.0 notes yet because I don't have the commit history. `/home/dev/project` isn't a git repository, and it only contains the release-notes skill, so there are no tags or commits to read.

I need one of these from you:

1. **The repo location.** If you run the export from your checkout, the command is `git log <previous-tag>..v1.0.0 > changes.txt`. Tell me the previous tag if it isn't obvious. If this is the first release, I'll use the full `git log v1.0.0`.
2. **A pasted or saved change list.** Send the `git log` output or the merged-PR list and I'll take it from there.

Once I have the list, I'll run the grouping script, fill in the template, and list any malformed or revert entries as questions for you. I won't tag, publish or post anything.