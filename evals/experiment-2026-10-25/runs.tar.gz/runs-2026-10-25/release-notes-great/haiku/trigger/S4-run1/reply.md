I can't draft the 1.5.0 notes yet because I don't have the list of changes. This directory isn't a git repository, and I didn't find a changelog, commit export, or `changes.txt` in it.

Could you send one of these?

1. **The repo with its tags.** Point me to the git repository and confirm the previous release tag (for example `v1.4.0`). I'll run `git log <previous-tag>..<new-tag> > changes.txt` and build the notes from that.
2. **A commit export.** Paste or upload the `git log` output for the 1.5.0 range.
3. **A list of merged changes.** Paste the PR titles or change list. Squash-merge titles work best.

Once I have the list, I'll group it with the script, write the notes with the 1.5.0 header, and list any problems I find as open questions for you to review. I won't tag or publish anything.