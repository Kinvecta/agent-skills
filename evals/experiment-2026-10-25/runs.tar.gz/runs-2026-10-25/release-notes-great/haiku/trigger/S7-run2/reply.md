I can't write the 0.9.0 entry yet because I don't have the commits. `/home/dev/project` isn't a git repository, and I found no commit list or log export in it. There's also no existing `CHANGELOG.md`, so I'd be creating the file from scratch.

To continue, paste one of these:

- The output of `git log --oneline v0.8.0..HEAD` (or whatever the previous tag is), or a list of the commit messages.
- A path to a git log export file.

Also tell me whether you want a new `CHANGELOG.md` created or whether the file lives somewhere else. Once I have the commits, I'll group them into Added, Changed, Fixed, and similar sections under a `## [0.9.0]` heading, and I'll use the release-notes skill for the grouping if that suits you.