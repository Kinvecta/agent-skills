I don't see the list of fixes. Your message didn't include it, and the project directory (`/home/dev/project`) has no changelog, release notes, or fix list. It also isn't a git repo, so I can't pull the changes from history.

Paste the list here, or point me to a file, and I'll draft the 1.2.1 patch notes. If you have a git repo with the 1.2.1 changes, tell me where it is and I can build the list from the commits instead.

It helps to include, for each item, a one-line description and, if you have them, the issue or PR numbers. I'll group the fixes by area and flag anything that reads as user-facing versus internal.