# session
model: claude-haiku-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll check the project for details about v2 before drafting.

## tool call: Bash
```
{"command": "ls -la && find . -maxdepth 2 -type f \\( -iname '*.md' -o -iname 'package.json' -o -iname '*.txt' -o -iname '*.toml' -o -iname '*.yaml' -o -iname '*.yml' -o -iname '*.json' \\) -not -path '*/node_modules/*' | head -50", "description": "List project files and docs"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 20:00 .
drwxr-xr-x 6 root root 4096 Oct 25 20:00 ..
drwxr-xr-x 3 root root 4096 Oct 25 20:00 .claude
drwxr-xr-x 3 root root 4096 Oct 25 20:00 skills
```

## tool call: Bash
```
{"command": "find . -type f | head -100 && echo --- && find .claude skills -type f -exec sh -c 'echo \"== $1\"; head -c 3000 \"$1\"; echo' _ {} \\; 2>/dev/null | head -300", "description": "Inspect all project files and their contents"}
```

## tool result
```
./.claude/skills/release-notes/SKILL.md
./.claude/skills/release-notes/templates/notes.md
./skills/release-notes/templates/notes.md
./.claude/skills/release-notes/scripts/group_changes.py
./skills/release-notes/scripts/group_changes.py
---
== skills/release-notes/scripts/group_changes.py
"""Group a git log export into release-note sections.

Usage:
  python3 group_changes.py changes.txt --version 1.4.0
  git log v1.3.0..v1.4.0 | python3 group_changes.py - --version 1.4.0

Input: plain `git log` output (commit / Author / Date / indented message), or one change
per line (`git log --oneline`, or a pasted list of merged PR titles).
Output: JSON on stdout with breaking, features, fixes, other, reverted, dropped,
contributors and problems. Diagnostics go to stderr. Reads only; writes nothing.
Ex …[truncated]
```

## assistant
I couldn't find anything about v2 here. This directory only holds release-notes tooling (`skills/release-notes/`), with no changelog, README, or product code. So I've written the post with bracketed placeholders instead of inventing features.

---

# Introducing [Product] v2: [one-line headline about the main benefit]

*[Month DD, 2026] · [Author name]*

[Two or three sentences that say what v2 is and why it exists. Open with the customer problem, not the version number. Example: "Many of you told us [specific pain point]. Today we're releasing [Product] v2, which [what it changes for them]."]

## What's new

**[Headline feature 1].** [What it does, in terms of what the customer can now do. One or two sentences. Include one concrete example if you have one.]

**[Headline feature 2].** [Same form.]

**[Headline feature 3].** [Same form.]

[Optional: a short quote from a customer or team member who helped shape v2. Use only with their permission.]

## What's better

- [Performance or reliability improvement, with a number if you can measure it: "Dashboards load in [X] seconds, down from [Y]."]
- [Fix or quality-of-life change that customers have asked for.]
- [Another improvement.]

## Upgrading to v2

[Say whether v2 is a drop-in upgrade or whether customers have to act. Keep this section even if the answer is "nothing to do."]

- **Breaking changes:** [List each one, or write "None."]
- **Migration steps:** [Steps, or a link to the migration guide: [URL]]
- **Timing:** [When v1 support ends, if relevant: "v1 will receive security fixes until [date]."]

## Get started

- [Upgrade now: link]
- [Read the full changelog: link]
- [Talk to us if you need help migrating: link or contact]

Thank you to everyone who sent feedback, filed bug reports, and tested the beta. v2 is better because of you.

---

**To finish this draft, I need:**

1. **The three to five changes that matter most to customers.** A changelog, a list of merged PRs, or a few bullet points is enough.
2. **Breaking changes and the migration path.** This section is where mistakes would hurt customers most, so I don't want to guess at it.
3. **Your product name, release date, author, and any real metrics or quotes you want to use.**
4. **Tone:** formal, friendly, or technical.

If you give me a git log export between the v1 and v2 tags, I can also use the release-notes skill to pull out the features, fixes, and breaking changes, then rewrite them for customers. That skill only drafts release notes, though, so I'd still write the blog framing here.
