# October 2026 Monthly Update

*Source: `tracker-2026-10.csv` (7 tasks), as of Oct 25.*

## Summary
2 of 7 tasks are complete. Two are in trouble: the wiki migration is blocked and past due, and the security scan of the new skills is at risk and also past due. The Q4 training rollout is on track for Oct 31.

## Completed
- **Vendor contract renewal** (Ana), done Oct 3.
- **Pilot survey close-out** (Raj), done Oct 9.

## On track
- **Q4 training rollout** (Lee), in progress, due Oct 31.
- **Onboarding guide update** (Lee), in progress, due Nov 5.

## Needs attention
| Item | Owner | Status | Due | Note |
|---|---|---|---|---|
| Wiki migration to new host | Sam | Blocked | Oct 15 | 10 days overdue. The tracker doesn't give the blocker. |
| Security scan of new skills | Raj | At risk | Oct 20 | 5 days overdue. |

## Coming up
- **FY27 budget draft** (Ana), not started, due Nov 12. About 2.5 weeks remain.

## Asks for leadership
- Help clear the wiki migration blocker. Sam should confirm what it is.
- Decide whether the new skills can be used before the security scan finishes. Raj should give a revised date.

## Caveats
- The tracker has no blocker details, risk reasons, or revised dates. Please add these from Sam and Raj before sending.
- Lee owns both in-progress items, so Lee's workload may be worth a check.
- I haven't added any accomplishments, metrics, or budget figures because the tracker doesn't contain them.

I can save this as a file, or shorten it to a short email or Slack post.