# October 2026 Monthly Update

This is based only on `tracker-2026-10.csv` (7 tasks). The tracker has no notes, so I haven't included causes, impact or metrics.

## Summary
- **2 of 7 tasks are done**, 2 are in progress, and 1 hasn't started.
- **2 tasks are past due and need attention:** the wiki migration (blocked) and the security scan of new skills (at risk).

## Completed
- **Vendor contract renewal** (Ana), done 10/3.
- **Close out pilot survey** (Raj), done 10/9.

## In progress
- **Q4 training rollout** (Lee), due 10/31.
- **Update onboarding guide** (Lee), due 11/5.

## Needs attention
| Item | Owner | Status | Due | Issue |
|---|---|---|---|---|
| Migrate wiki to new host | Sam | Blocked | 10/15 | 10 days overdue. |
| Security scan of new skills | Raj | At risk | 10/20 | 5 days overdue. |

## Coming up
- **Budget draft for FY27** (Ana), due 11/12. It hasn't started.

## Asks and open questions
- **Wiki migration:** the tracker doesn't say what is blocking it. Sam should confirm the blocker and what's needed to clear it.
- **Security scan:** Raj should confirm a revised date.
- **Q4 training rollout:** it's due in 6 days. Lee should confirm it's on track.

Before this goes out, I'd add the blocker details, revised dates, and any wins or metrics that aren't in the tracker. I can reformat it as an email or a slide if you'd like.