I drafted the report and saved it to `/home/dev/project/status-report-2026-10.md`. The status counts and overdue figures are measured from today, 2026-10-25.

**Status of the 7 tasks**
- **Done (2):** Vendor contract renewal and Close out pilot survey.
- **In progress (2):** Q4 training rollout, due 10-31, and Update onboarding guide, due 11-05. Both are Lee's.
- **At risk (1):** Security scan of new skills (Raj), 5 days overdue.
- **Blocked (1):** Migrate wiki to new host (Sam), 10 days overdue.
- **Not started (1):** Budget draft for FY27 (Ana), due 11-12.

The tracker doesn't say why the wiki migration is blocked. I left that out of the report and added a note to confirm it with Sam before you send it.