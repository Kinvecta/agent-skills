I can't draft this report yet. The project has no logs, alerts, timeline, or notes about yesterday's outage (2026-10-24). The only files are skill definitions under `.claude/`. I don't want to invent details for a document people will rely on.

Here is what I need from you. Partial answers are fine, and I'll mark any gaps as TBD.

1. **Impact:** Which services or users were affected? What were the start and end times, with timezone?
2. **Detection:** Did an alert, a customer report, or a person notice it first?
3. **Timeline:** Key events such as deploys, config changes, escalations, mitigation steps, and the resolution.
4. **Cause:** The root cause if you know it, or your best hypothesis.
5. **Evidence:** Paths to logs, monitoring exports, or a chat or ticket thread I can read.
6. **Follow-ups:** Any action items already agreed, with owners.
7. **Format:** A template your team uses, or should I use a standard layout? The standard one has summary, impact, timeline, root cause, resolution, what went well and badly, and action items.

You can paste the raw material here or point me to files, and I'll write the draft from that.