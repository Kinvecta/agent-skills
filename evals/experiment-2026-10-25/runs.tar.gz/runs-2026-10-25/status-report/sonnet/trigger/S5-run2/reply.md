I couldn't find a tracker export in `/home/dev/project`. The only files there are the skill's own, and there are no CSVs.

To build the report I need two things:
1. **The path to the tracker CSV.** It needs the columns `task, owner, status, due`.
2. **The report month** as `YYYY-MM`. Should I use 2026-10, the current month, or a different one?

Once I have the path, I'll run the totals script and fill in the template.