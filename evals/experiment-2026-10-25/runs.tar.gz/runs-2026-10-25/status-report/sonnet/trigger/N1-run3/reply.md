I can't draft the v1.4.0 notes yet because there's no change list to work from.

- `/home/dev/project` isn't a git repository, so I can't export a log with `git log <previous-tag>..v1.4.0`.
- The project has no `changes.txt` or any other export of merged changes.

I haven't run the grouping script or filled in the template. Anything I wrote now would be invented.

Please send one of these:
1. **A git log export or pasted list of merged changes** for v1.4.0.
2. **The repo location and the previous tag**, such as `v1.3.0`, if the repo is somewhere else. I'll export the range myself.

I'll use `1.4.0` as the header version, taken from the tag you gave.