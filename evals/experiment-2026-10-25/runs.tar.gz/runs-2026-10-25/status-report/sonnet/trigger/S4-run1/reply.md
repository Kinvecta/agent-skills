I can't write the report yet because there's no tracker CSV in `/home/dev/project`. I searched for one and found none. The status-report process builds the report from a tracker export with the columns `task, owner, status, due`, and every number has to come from its totals script.

Which file should I use? Give me the path, or drop the export into the project. I'll assume the month is October 2026 (2026-10) unless you say otherwise.

Once I have it, I'll run the totals script and fill in the report template. The report will cover what's open and at risk this month, what's blocked, and what's due next month, with an owner named on each open task. It will be a draft for you to review before it goes to your director.