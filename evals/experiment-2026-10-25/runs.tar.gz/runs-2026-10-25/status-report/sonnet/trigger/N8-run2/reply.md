I can't draft a real incident report yet. The project has no logs, alerts, timeline, or notes about yesterday's outage (2026-10-24). It only contains skill definitions under `.claude/`, and none of them cover incident reports. I'd rather not invent details, so I need some facts from you.

**What I need**
- **Impact:** which service or users were affected, how badly (full or partial outage), and roughly how many users.
- **Timeline:** when it started, when it was detected and by whom or what, when it was mitigated, and when it was resolved. Please include time zones.
- **Cause:** the root cause, or your best current hypothesis.
- **Response:** what was done to fix it, and who was involved.
- **Follow-ups:** any action items you already have in mind.

You can paste raw material instead, such as chat logs, alert history, a deploy log, or dashboard notes. I'll pull the timeline out of it. If the evidence is somewhere on this machine, give me the path.

**Format**
I'll use a standard blameless layout unless you have a template:
- Summary
- Impact
- Timeline
- Root cause
- Detection
- Resolution
- What went well and what didn't
- Action items with owners

Tell me if you want a different format, or if it should go somewhere specific, such as a file in the project.