# session
model: claude-sonnet-5-5
skills listed: status-report, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "status-report"}
```

## tool result
```
Launching skill: status-report
```

## tool call: Bash
```
{"command": "ls; cd .claude/skills/status-report && ls -R . && cat templates/report.md references/style.md; cd /home/dev/project && find . -name tracker-tricky.csv"}
```

## tool result
```
tracker-tricky.csv
.:
SKILL.md
references
scripts
templates

./references:
style.md

./scripts:
totals.py

./templates:
report.md
# Status report: {month}

**Summary.** {two or three sentences: overall health, the biggest risk, the one decision needed}

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| {done} | {in progress} | {at risk} | {blocked} | {not started} | {total} |

## Due this month, not done

{one line per task: task, owner, due date, status. Write "None." if the list is empty.}

## Due next month

{one line per task: task, owner, due date}

## Decisions needed

{bullets, or "None."}
# Style for status reports

- Lead with the answer: is the project on track, yes or no.
- Plain words. No hype ("exciting", "game-changing").
- Name peop …[truncated]
```

## tool call: Bash
```
{"command": "python3 .claude/skills/status-report/scripts/totals.py tracker-tricky.csv --month 2026-10; echo; cat tracker-tricky.csv"}
```

## tool result
```
{
  "month": "2026-10",
  "total": 3,
  "counts": {
    "done": 1,
    "in progress": 1,
    "at risk": 1,
    "blocked": 0,
    "not started": 0
  },
  "due_this_month_not_done": [
    {
      "task": "Q4 training rollout",
      "owner": "Lee",
      "due": "2026-10-31"
    }
  ],
  "due_next_month": [],
  "problems": [
    "line 3: bad due date '10/31/2026'"
  ]
}

task,owner,status,due
Vendor contract renewal,Ana,Done ,2026-10-03
Security scan of new skills,Raj,at risk,10/31/2026
Q4 training rollout,Lee,in progress,2026-10-31
```

## assistant
# Status report: 2026-10

**Summary.** Not clearly on track. Of 3 tasks, 1 is done, 1 is in progress and 1 is at risk. The biggest risk is the security scan of new skills, which is at risk with a due date of 2026-10-31. No decision is needed beyond confirming that due date (see below).

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | 0 | 3 |

## Due this month, not done

- Q4 training rollout, Lee, due 2026-10-31, in progress
- Security scan of new skills, Raj, due 2026-10-31, at risk (see the note under "Decisions needed")

## Due next month

None.

## Decisions needed

- Confirm the due date of "Security scan of new skills". The tracker has it as `10/31/2026`, which the totals script rejected as a bad date. I read it as 2026-10-31 and added the task to the "due this month" list by hand. The counts above come from the script and include this task.
- Fix that cell in the tracker to `2026-10-31`, so the script lists the task on its own next time.

---
*Draft for review. Not sent or posted.*
