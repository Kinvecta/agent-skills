# session
model: claude-sonnet-5-5
skills listed: status-report, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "status-report"}
```

## tool result
```
Launching skill: status-report
```

## tool call: Bash
```
{"command": "cd /home/dev/project; find . -name tracker-tricky.csv; cd .claude/skills/status-report && ls -R . && cat templates/report.md"}
```

## tool result
```
./tracker-tricky.csv
.:
SKILL.md
references
scripts
templates

./references:
style.md

./scripts:
totals.py

./templates:
report.md
# Status report: {month}

**Summary.** {two or three sentences: overall health, the biggest risk, the one decision needed}

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| {done} | {in progress} | {at risk} | {blocked} | {not started} | {total} |

## Due this month, not done

{one line per task: task, owner, due date, status. Write "None." if the list is empty.}

## Due next month

{one line per task: task, owner, due date}

## Decisions needed

{bullets, or "None."}
```

## tool call: Bash
```
{"command": "python3 scripts/totals.py /home/dev/project/tracker-tricky.csv --month 2026-10; cat references/style.md"}
```

## tool result
```
{
  "month": "2026-10",
  "total": 3,
  "counts": {
    "done": 1,
    "in progress": 1,
    "at risk": 1,
    "blocked": 0,
    "not started": 0
  },
  "due_this_month_not_done": [
    {
      "task": "Q4 training rollout",
      "owner": "Lee",
      "due": "2026-10-31"
    }
  ],
  "due_next_month": [],
  "problems": [
    "line 3: bad due date '10/31/2026'"
  ]
}
# Style for status reports

- Lead with the answer: is the project on track, yes or no.
- Plain words. No hype ("exciting", "game-changing").
- Name people by role or first name, the way the tracker does.
- Numbers come from the script. Never round or estimate them.
- Keep the whole report to one page (about 250 words).
```

## tool call: Bash
```
{"command": "cat /home/dev/project/tracker-tricky.csv"}
```

## tool result
```
task,owner,status,due
Vendor contract renewal,Ana,Done ,2026-10-03
Security scan of new skills,Raj,at risk,10/31/2026
Q4 training rollout,Lee,in progress,2026-10-31
```

## assistant
# Status report: 2026-10

**Summary.** The project is not clearly on track: 1 of 3 tasks is done, and 1 is at risk. The biggest risk is the at-risk security scan, which is missing from the due list below because of a date-format error in the tracker (see the note). No decision is needed beyond fixing that date.

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | 0 | 3 |

## Due this month, not done

- Q4 training rollout, Lee, 2026-10-31, in progress

## Due next month

None.

## Decisions needed

None.

---

**Note for the reviewer (delete before sending):**
- Line 3 of `tracker-tricky.csv` has the due date `10/31/2026` instead of `YYYY-MM-DD`. The totals script flagged it and left it out of the due lists.
- That row is "Security scan of new skills", owner Raj, status at risk. It is probably due 2026-10-31, which would put it in "Due this month, not done". I didn't add it, because I don't want to guess at the date.
- The counts still include this task, so the totals of 3 are correct.
- If you confirm the date, I can fix the CSV and re-run the script.
- Raj's task would then also be the biggest risk named in the summary.
- The tracker also has a trailing space in the first row's status ("Done "). The script counted it as done anyway.
