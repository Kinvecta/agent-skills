# Status report: 2026-10

**Summary.** The project is not clearly on track: 1 of 3 tasks is done, and 1 is at risk. The biggest risk is the at-risk security scan, which is missing from the due list below because of a date-format error in the tracker (see the note). No decision is needed beyond fixing that date.

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | 0 | 3 |

## Due this month, not done

- Q4 training rollout, Lee, 2026-10-31, in progress

## Due next month

None.

## Decisions needed

None.

---

**Note for the reviewer (delete before sending):**
- Line 3 of `tracker-tricky.csv` has the due date `10/31/2026` instead of `YYYY-MM-DD`. The totals script flagged it and left it out of the due lists.
- That row is "Security scan of new skills", owner Raj, status at risk. It is probably due 2026-10-31, which would put it in "Due this month, not done". I didn't add it, because I don't want to guess at the date.
- The counts still include this task, so the totals of 3 are correct.
- If you confirm the date, I can fix the CSV and re-run the script.
- Raj's task would then also be the biggest risk named in the summary.
- The tracker also has a trailing space in the first row's status ("Done "). The script counted it as done anyway.