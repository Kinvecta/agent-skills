# session
model: claude-sonnet-5-5
skills listed: status-report, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "status-report"}
```

## tool result
```
Launching skill: status-report
```

## tool call: Bash
```
{"command": "cd /home/dev/project/.claude/skills/status-report && ls; find /home/dev/project -name tracker-tricky.csv; cat templates/report.md"}
```

## tool result
```
SKILL.md
references
scripts
templates
/home/dev/project/tracker-tricky.csv
# Status report: {month}

**Summary.** {two or three sentences: overall health, the biggest risk, the one decision needed}

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| {done} | {in progress} | {at risk} | {blocked} | {not started} | {total} |

## Due this month, not done

{one line per task: task, owner, due date, status. Write "None." if the list is empty.}

## Due next month

{one line per task: task, owner, due date}

## Decisions needed

{bullets, or "None."}
```

## tool call: Bash
```
{"command": "python3 scripts/totals.py /home/dev/project/tracker-tricky.csv --month 2026-10; cat references/style.md"}
```

## tool result
```
{
  "month": "2026-10",
  "total": 3,
  "counts": {
    "done": 1,
    "in progress": 1,
    "at risk": 1,
    "blocked": 0,
    "not started": 0
  },
  "due_this_month_not_done": [
    {
      "task": "Q4 training rollout",
      "owner": "Lee",
      "due": "2026-10-31"
    }
  ],
  "due_next_month": [],
  "problems": [
    "line 3: bad due date '10/31/2026'"
  ]
}
# Style for status reports

- Lead with the answer: is the project on track, yes or no.
- Plain words. No hype ("exciting", "game-changing").
- Name people by role or first name, the way the tracker does.
- Numbers come from the script. Never round or estimate them.
- Keep the whole report to one page (about 250 words).
```

## tool call: Bash
```
{"command": "cat /home/dev/project/tracker-tricky.csv"}
```

## tool result
```
task,owner,status,due
Vendor contract renewal,Ana,Done ,2026-10-03
Security scan of new skills,Raj,at risk,10/31/2026
Q4 training rollout,Lee,in progress,2026-10-31
```

## assistant
# Status report: 2026-10

**Summary.** The project is not fully on track. One of three tasks is done, one is in progress, and one is at risk: the security scan of new skills (Raj). The Q4 training rollout (Lee) is due 2026-10-31, the same day as the at-risk scan. No decision is needed, but Raj should confirm whether the scan can finish by then.

| Done | In progress | At risk | Blocked | Not started | Total |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | 0 | 3 |

## Due this month, not done

- Security scan of new skills, Raj, 2026-10-31, at risk (see the note below)
- Q4 training rollout, Lee, 2026-10-31, in progress

## Due next month

None.

## Decisions needed

None.

---
**Reviewer note (delete before sending).** The totals script flagged line 3 of `tracker-tricky.csv`. The due date for "Security scan of new skills" is written `10/31/2026`, so the script left that task out of its "due this month, not done" list. I read it as 2026-10-31 and added the task by hand. Please confirm the date and fix it in the tracker. The counts come straight from the script, which counted all three rows. The "Done" status on the vendor contract row had a trailing space, and the script still counted it as done.
