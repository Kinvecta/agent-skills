# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes", "args": "v2.0.0 from git-log-tricky.txt"}
```

## tool result
```
Launching skill: release-notes
```

## tool call: Bash
```
{"command": "ls; ls skills/release-notes/scripts .claude/skills/release-notes/scripts 2>&1; find . -name git-log-tricky.txt"}
```

## tool result
```
git-log-tricky.txt
skills
.claude/skills/release-notes/scripts:
group_changes.py

skills/release-notes/scripts:
group_changes.py
./git-log-tricky.txt
```

## tool call: Bash
```
{"command": "python3 skills/release-notes/scripts/group_changes.py git-log-tricky.txt --version v2.0.0; echo ---; cat git-log-tricky.txt"}
```

## tool result
```
{
  "version": "2.0.0",
  "breaking": [
    {
      "type": "feat",
      "scope": "config",
      "description": "read settings from tidy.toml",
      "pr": 152,
      "hash": "b8a9f0e",
      "author": "Raj Patel",
      "breaking_note": "tidy.ini is no longer read. Rename it to tidy.toml and run `tidy config migrate` once."
    },
    {
      "type": "fix",
      "scope": null,
      "description": "drop support for Python 3.9",
      "pr": 146,
      "hash": "748596a",
      "author": "Ana Ruiz",
      "breaking_note": null
    }
  ],
  "features": [],
  "fixes": [
    {
      "type": "fix",
      "scope": "cli",
      "description": "exit code is 1, not 0, when a file is missing",
      "pr": 149,
      "hash": "a7b8c9d",
      "author": "Sam Okafor",
      "breaking_note": null
    } …[truncated]
```

## assistant
# v2.0.0

## Breaking changes

- **config:** Settings are now read from `tidy.toml`. `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once. (#152)
- Dropped support for Python 3.9. (#146)

## Fixes

- **cli:** The exit code is now 1, not 0, when a file is missing. (#149)

## Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Items to check before publishing**

- **Missing entry:** `feat(api add pagination to list endpoint (#148)` is malformed because the closing parenthesis after `api` is missing. The script left it out, so I did too. It is probably a feature, `feat(api): add pagination to list endpoint`. If it shipped in 2.0.0, add it under Features.
- **No migration note for #146:** The Python 3.9 drop is a breaking change with no migration note. You may want a line such as "Upgrade to Python 3.10 or newer".
- **Commit type:** #146 is committed as `fix!`, so the script groups it under breaking changes.
- **Excluded:** The bulk delete endpoint (#151) was added and then reverted, so it isn't listed. Two dependency bumps and one merge commit were also dropped.
- **Version header:** The script outputs `2.0.0`. I used `v2.0.0` to match what you asked for.
