# v2.0.0

## Breaking changes

- **config:** Settings are now read from `tidy.toml`. `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once. (#152)
- Dropped support for Python 3.9. (#146)

## Fixes

- **cli:** The exit code is now 1, not 0, when a file is missing. (#149)

## Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Items to check before publishing**

- **Missing entry:** `feat(api add pagination to list endpoint (#148)` is malformed because the closing parenthesis after `api` is missing. The script left it out, so I did too. It is probably a feature, `feat(api): add pagination to list endpoint`. If it shipped in 2.0.0, add it under Features.
- **No migration note for #146:** The Python 3.9 drop is a breaking change with no migration note. You may want a line such as "Upgrade to Python 3.10 or newer".
- **Commit type:** #146 is committed as `fix!`, so the script groups it under breaking changes.
- **Excluded:** The bulk delete endpoint (#151) was added and then reverted, so it isn't listed. Two dependency bumps and one merge commit were also dropped.
- **Version header:** The script outputs `2.0.0`. I used `v2.0.0` to match what you asked for.