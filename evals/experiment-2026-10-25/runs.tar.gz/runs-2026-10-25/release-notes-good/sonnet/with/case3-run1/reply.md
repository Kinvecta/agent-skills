# v2.0.0

## Breaking changes

- **config:** Settings are now read from `tidy.toml`. `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once. (#152)
- Dropped support for Python 3.9. (#146)

## Fixes

- **cli:** The exit code is now 1, not 0, when a file is missing. (#149)

## Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**Open items before you publish:**

1. **Missing commit:** `feat(api add pagination to list endpoint (#148)` is missing its closing parenthesis, so the script skipped it. It is probably a feature, and the notes have no Features section because of it. Fix the commit message or tell me to add it by hand. Lee Chen would also be added to the contributors.
2. **No migration note for Python 3.9:** #146 is marked breaking (`fix!:`) but has no `BREAKING CHANGE:` text. I kept the entry as is. You may want to say which Python versions are now supported.
3. **Left out on purpose:**
   - The bulk delete endpoint (#151) was reverted, so it isn't listed.
   - Two dependency bumps and one merge commit were dropped.
4. **Fix to consider:** #149 changes exit codes, so scripts that relied on the old exit code 0 may break. You may want to move it to Breaking changes.