# Release notes: 1.4.0

## Features
- **export:** Added `--format csv` to the export command (#142)
- Show a progress bar for uploads over 10 MB (#138)

## Fixes
- **sync:** Retry once when the server returns 503 (#140)
- A config file path with spaces is no longer split (#137)

## Other changes
- **readme:** Documented the export command (#135)
- **index (perf):** The search index is now built in one pass (#134)

## Contributors
Ana Ruiz, Raj Patel, Sam Okafor

This release has no breaking changes. The script left out one `chore` and one `ci` commit as internal. Every entry above comes from the script's output, and the header version matches the 1.4.0 I passed in.