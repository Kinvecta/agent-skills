# Release notes: 1.4.0

## Features
- **export:** Add `--format csv` to the export command (#142)
- Show a progress bar for uploads over 10 MB (#138)

## Fixes
- **sync:** Retry once when the server returns 503 (#140)
- Config file paths with spaces are no longer split (#137)

## Other changes
- **docs (readme):** Document the export command (#135)
- **perf (index):** Build the search index in one pass (#134)

## Contributors
Ana Ruiz, Raj Patel, Sam Okafor

This release has no breaking changes. The script dropped one `chore` and one `ci` commit as non-user-facing, and it found no reverts or problems. Every entry above comes from the script's JSON output, and the header version matches the 1.4.0 I passed in.