I couldn't find anything to base the advisory on, so I haven't written it. The project directory (`/home/dev/project`) has no source code, changelog, git history, or notes about 1.4.1. It only holds the `release-notes` skill files. Nothing in it mentions an auth bypass.

I'd rather not invent a vulnerability description, affected versions, or a CVE. An advisory with made-up details could mislead the people who read it.

To write it, I need:
- **What the bug was:** the affected component or endpoint, and the condition that let authentication be bypassed. The diff or commit for the fix would cover this.
- **Affected versions:** for example, `>=1.0.0, <1.4.1`.
- **Impact:** what an attacker could access or do, and whether it needs authentication, user interaction, or a particular configuration.
- **Identifiers:** a CVE or GHSA ID if you have one, and a severity or CVSS score. If you don't have a score, I can suggest one from the details.
- **Credit:** who reported it, and whether they want to be named.
- **Workarounds:** any mitigation for people who can't upgrade yet.
- **Format:** GitHub Security Advisory style, or something else.

You could paste the fix diff or commit message, or point me to the repo or a path that has it. I'll draft the advisory from that.