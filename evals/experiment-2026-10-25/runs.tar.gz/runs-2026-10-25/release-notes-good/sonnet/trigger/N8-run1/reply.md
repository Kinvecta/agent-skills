I can't write an accurate tweet yet. The project has no changelog, README, version file or git history, so I don't know what's in the release.

Send me any of these and I'll draft it:
- The product name and version
- 2–3 headline changes or features
- A link, if you want one in the tweet
- The tone you want (excited, understated, technical)

Here's a template you can fill in meanwhile:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Notable fix]
>
> Update today: [link]

If you paste a git log or a list of merged changes, I can also use the `release-notes` skill to draft full notes and then cut them down to a tweet.