There's nothing here to attach semantic-release to yet. `/home/dev/project` has no `package.json`, no git repository, no CI config, and no existing changelog. It only contains a `release-notes` skill, which appears twice, under `skills/` and `.claude/skills/`. I haven't changed anything.

Before I scaffold anything, I need to know:

1. **CI platform:** GitHub Actions, GitLab CI, or something else?
2. **Repo location:** Is this the right directory? If so, should I run `git init` and add a `package.json` from scratch? Or is the real repo somewhere else?
3. **Publishing:** Do you want only `CHANGELOG.md` and GitHub releases, or also an npm publish?
4. **Commit convention:** Do you use Conventional Commits? semantic-release derives versions and changelog entries from them. The default is the Angular preset.

Once you answer, I'll add:
- `package.json` with `semantic-release`, `@semantic-release/changelog`, and `@semantic-release/git` as dev dependencies
- A `.releaserc.json` with the plugin chain: commit-analyzer, release-notes-generator, changelog, git (to commit `CHANGELOG.md` back), and github
- A CI workflow that checks out with full history, sets up Node, and runs `npx semantic-release` on pushes to `main`, with the permissions and token it needs