I haven't changed anything yet, because this directory doesn't have what semantic-release needs. It holds only `.claude/skills/release-notes/` and a `skills/release-notes/` copy. There's no `package.json`, no git repository, no CI config, and no existing changelog.

Two questions before I set it up:

1. **Which CI system do you use?** I'd default to GitHub Actions (`.github/workflows/release.yml`). If you use GitLab CI or something else, I'd write that instead.
2. **Where should this go?** Is this the right directory, or is the real repo somewhere else? If it is the right one, I'd create a minimal `package.json` and run `git init`. The `package.json` would hold the semantic-release dev dependencies. Commit analysis needs Conventional Commits, and the release needs a git remote.

Unless you say otherwise, I'll set it up like this:
- **Plugins:** `commit-analyzer`, `release-notes-generator`, `changelog` (writes `CHANGELOG.md`), `git` (commits the changelog back), and `github` (publishes the release).
- **Config:** a `.releaserc.json` that releases from `main`.
- **Workflow:** a job that runs on push to `main`. It checks out with full history (`fetch-depth: 0`) and runs `npx semantic-release` with `GITHUB_TOKEN`.
- **npm publishing:** off (`npmPublish: false`), since this doesn't look like a published package.

Let me know if any of that should change.