I can't write the release notes yet because I don't have the git log. Nothing came through with your message. `/home/dev/project` isn't a git repository, and I found no changes file there.

Please send:
1. **The change list.** You can paste the log, give me a file path, or tell me the tags to compare, for example `v1.2.0..v1.3.0`. If the tags are in another repo, tell me where it is.
2. **The version number** for the release header.

Once I have both, I'll run the grouping script (`skills/release-notes/scripts/group_changes.py`). Then I'll write the notes with breaking changes first, followed by features, fixes and other changes, each with its PR number.