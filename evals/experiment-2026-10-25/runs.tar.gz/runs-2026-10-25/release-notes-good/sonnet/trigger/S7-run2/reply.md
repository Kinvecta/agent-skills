I can't write the 0.9.0 entry yet, for two reasons:

- **No commits came through.** Your message said "using these commits", but I only got the text of the request. The project isn't a git repo, so I can't run `git log`, and there's no `changes.txt` or similar file.
- **There's no `CHANGELOG.md`.** I'd be creating one rather than updating one. Is that what you want, or is it in a different location?

Please paste the commit list (ideally with PR numbers), or give me the path to a file that has it. Once I have it, I'll run it through `group_changes.py --version 0.9.0` and write the entry.