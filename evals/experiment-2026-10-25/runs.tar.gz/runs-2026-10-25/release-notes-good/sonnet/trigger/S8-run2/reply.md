I can't write the notes yet because I have no list of changes for v1.0.0. `/home/dev/project` isn't a git repository, so I can't run `git log` between tags. There's also no changes file or CHANGELOG in the project.

The release-notes skill groups changes with `group_changes.py` and then writes the notes from that output. Send me one of these:

- **A file path** containing the changes, such as a `git log --oneline` export or a list of merged PRs.
- **Pasted text** of the same list.
- **The repo location**, if the tagged repo lives somewhere else on this machine. I can run `git log <previous-tag>..v1.0.0` there. Tell me the previous tag, or say so if v1.0.0 is the first release.

Once I have the list, I'll run it through the script and draft the notes. They'll put breaking changes first, then features, fixes and other changes, each with its PR number.