I couldn't bump the version because there's no `package.json` in `/home/dev/project`. A recursive search, skipping `node_modules`, found none. I haven't changed anything.

If the project is somewhere else, tell me the path. If you want a new `package.json` created with version 1.5.0, I can do that.