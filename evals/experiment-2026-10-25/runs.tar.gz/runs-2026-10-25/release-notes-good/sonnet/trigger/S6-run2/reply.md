I can't write the notes yet because `/home/dev/project` isn't a git repository. `git log v2.3.0..v2.4.0` failed with "not a git repository", and the directory has no change list or export either. It only contains the `release-notes` skill's `group_changes.py` script.

To go ahead, I need one of these:
- **The repo path:** if the project is cloned somewhere else, I'll run `git log v2.3.0..v2.4.0` there.
- **A change list:** a file or pasted text with the commits or merged PRs, ideally with PR numbers. I'll run it through `group_changes.py --version 2.4.0` and write the notes from the output.

Which would you like to do?