I can't write the 0.9.0 entry yet because I don't have the commits. Your message says "these commits", but nothing came through with it. The project isn't a git repo, so I can't run `git log` either. There's also no `CHANGELOG.md` yet, so I'd be creating one.

Please do one of these:
- Paste the commit list or merged PRs, ideally with PR numbers.
- Give me a file path that holds them.
- Give me the previous and new tags, if the commits live in a repo elsewhere.

Once I have them, I'll run them through the grouping script (`skills/release-notes/scripts/group_changes.py … --version 0.9.0`). Then I'll write the 0.9.0 section of `CHANGELOG.md`, with breaking changes first, then features, fixes and other changes.