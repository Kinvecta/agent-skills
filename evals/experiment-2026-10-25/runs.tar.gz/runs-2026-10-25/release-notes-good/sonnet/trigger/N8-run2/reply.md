I couldn't find any details about the release. The project has no changelog, README, version file, or git history, so I'd be making up the features if I wrote the tweet now.

Send me any of these and I'll write it:
- the product name and version number
- the 2–3 headline changes or features
- a link, if you want one in the tweet
- the tone you want (excited, understated, technical)

You could also paste a git log or a list of merged changes. I can use the `release-notes` skill to summarize them first, then turn that into the tweet.

Here's a template to show the shape:

> 🚀 [Product] [vX.Y] is out!
>
> ✨ [Headline feature]
> ⚡ [Second improvement]
> 🐛 [Notable fix]
>
> Details and upgrade notes: [link]