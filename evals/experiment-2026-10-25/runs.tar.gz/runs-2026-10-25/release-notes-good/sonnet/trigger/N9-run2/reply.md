I couldn't find a tracker CSV. The project directory (`/home/dev/project`) has no `.csv` files. It holds only the `release-notes` skill files. A filename search for "tracker" outside the usual system and package directories found nothing relevant.

Can you give me one of these?
- The path to the tracker CSV, or the file itself dropped into the project
- The reporting month, if the CSV covers more than one
- A template or an earlier report to match, if you have one. Otherwise I'll use a simple format: summary, completed, in progress, blocked or at risk, and next month.

Once I have the file, I'll draft the report.