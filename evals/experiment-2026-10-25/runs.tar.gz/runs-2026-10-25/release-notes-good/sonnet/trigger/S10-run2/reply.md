I don't see the log in your message, so there's nothing for me to write up yet. `/home/dev/project` isn't a git repository either, so I can't run it myself.

Can you paste the output of `git log v4.1.0..v4.2.0`? Something like `git log --no-merges --format='%h %s%n%b' v4.1.0..v4.2.0` would work well, since it includes commit bodies. If you tell me where the repo is, I can run it myself.