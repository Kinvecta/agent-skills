# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes"}
```

## tool result
```
Launching skill: release-notes
```

## assistant
I don't have the git log yet. The message came through without it, and `/home/dev/project` isn't a git repository, so I can't generate it myself.

Please send:
1. **The change list.** Paste it here, give me a file path, or tell me the tag range (for example `v1.2.0..v1.3.0`) if the repo is somewhere else.
2. **The version number** for the release notes header.

Once I have both, I'll group the changes with the skill's script. I'll then write the notes with breaking changes first, followed by features, fixes and other changes, each with its PR number.
