I can't produce the summary yet. `/home/dev/project` isn't a git repository, so `git log v2.3.0..v2.4.0` failed and I have no commits to work from.

Either of these would unblock me:
- **Repo path:** the location of the clone that has the `v2.3.0` and `v2.4.0` tags.
- **Change list:** the output of `git log v2.3.0..v2.4.0 --oneline`, or a list of the merged PRs, pasted here or saved to a file.

Once I have one, I'll run it through `group_changes.py` with `--version 2.4.0` and write the notes. They'll list breaking changes first, then features, fixes and other changes, each with its PR number.