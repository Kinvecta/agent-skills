# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
The git log didn't come through. Your message ends right after "below" with nothing attached. Can you paste it again?

If you want the entry to match your existing style, tell me where your current changelog lives, for example `CHANGELOG.md`. Otherwise I'll use a standard Keep a Changelog layout.
