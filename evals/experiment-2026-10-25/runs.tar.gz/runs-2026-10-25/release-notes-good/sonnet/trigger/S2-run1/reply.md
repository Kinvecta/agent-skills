The git log didn't come through. Your message ends right after "below" with nothing attached. Can you paste it again?

If you want the entry to match your existing style, tell me where your current changelog lives, for example `CHANGELOG.md`. Otherwise I'll use a standard Keep a Changelog layout.