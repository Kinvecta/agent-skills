I can't write the 1.5.0 notes yet because I don't have a list of changes. `/home/dev/project` isn't a git repo, so there's no log to read, and I found no `changes.txt` or similar file.

Please send one of these:
- The merged PRs or commits since the last release, pasted here. Include the PR numbers.
- A file path, if you've already exported the list.
- The git repo location and the previous tag, if the history lives somewhere else.

Once I have it, I'll run it through `group_changes.py` with `--version 1.5.0`. I'll then write the notes with breaking changes first, followed by features, fixes and other changes, each with its PR number.