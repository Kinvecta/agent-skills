I can't write this advisory yet. The project has no information about the 1.4.1 fix. The directory isn't a git repo and has no source code, changelog, or commit history. It holds only the `release-notes` skill files, and none of them mention 1.4.1 or an auth bypass. If I filled in the details myself, I'd be inventing facts in a security document.

Please send me the following:

**Required**
- **Product and package name**, with the ecosystem (npm, PyPI, and so on).
- **Affected versions**, for example `>=1.0.0, <1.4.1`.
- **What the bypass is.** Describe the vulnerable code path, the conditions needed to trigger it, and whether it needs authentication or user interaction.
- **Impact.** For example, unauthenticated access to X, or privilege escalation to admin.
- **The fix.** A commit or PR link, or a description of the change.

**Optional, but I'd include them if you have them**
- A CVE or GHSA ID. If you don't have one yet, I'll leave a placeholder.
- A severity rating. I can propose a CVSS vector from the details above if you want one.
- Workarounds for people who can't upgrade right away.
- Reporter credit, and whether they want to be named.
- Timeline: report date, fix date, and release date.
- Whether there is any evidence of exploitation.

The easiest route is to paste the fix diff or commit message, or the `git log` between 1.4.0 and 1.4.1. I'll draft the advisory from that, in GitHub Security Advisory format unless you want a different one.