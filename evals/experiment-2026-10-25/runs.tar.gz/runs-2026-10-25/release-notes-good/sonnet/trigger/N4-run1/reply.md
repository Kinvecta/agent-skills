I can't write a commit message because `/home/dev/project` isn't a git repository, so there are no staged changes to read. `git diff --staged` failed and fell back to its no-repo mode.

Here are two ways to fix that:
- **Different directory:** if the repo is somewhere else, give me the path and I'll check it there.
- **Pasted diff:** paste the output of `git diff --staged` here and I'll write the message from it.