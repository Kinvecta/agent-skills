I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends after "Here are the merged PRs since the last tag", with nothing attached. I also looked in `/home/dev/project` for a changes file and found none. The directory isn't a git repo, so I can't run `git log` for the tag range either.

Either of these would work:
- Paste the PR list here, with titles and numbers.
- Give me the path to a file that contains it.

Once I have the list, I'll run it through the skill's `group_changes.py` with `--version 3.1`. Then I'll write the notes with breaking changes first, followed by features, fixes and other changes, each with its PR number.

One thing to check on your side: the skill's instructions call the script at `skills/release-notes/scripts/group_changes.py`. The copy I found is at `.claude/skills/release-notes/scripts/group_changes.py`, so I'll use that path.