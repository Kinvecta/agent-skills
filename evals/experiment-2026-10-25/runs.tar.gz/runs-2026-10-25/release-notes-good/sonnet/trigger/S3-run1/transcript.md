# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes", "args": "3.1"}
```

## tool result
```
Launching skill: release-notes
```

## tool call: Bash
```
{"command": "ls; ls .claude/skills/release-notes .claude/skills/release-notes/scripts 2>&1; find . -maxdepth 2 -iname '*change*' -not -path './node_modules/*' | head"}
```

## tool result
```
skills
.claude/skills/release-notes:
SKILL.md
scripts
templates

.claude/skills/release-notes/scripts:
group_changes.py
```

## assistant
I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends after "Here are the merged PRs since the last tag", with nothing attached. I also looked in `/home/dev/project` for a changes file and found none. The directory isn't a git repo, so I can't run `git log` for the tag range either.

Either of these would work:
- Paste the PR list here, with titles and numbers.
- Give me the path to a file that contains it.

Once I have the list, I'll run it through the skill's `group_changes.py` with `--version 3.1`. Then I'll write the notes with breaking changes first, followed by features, fixes and other changes, each with its PR number.

One thing to check on your side: the skill's instructions call the script at `skills/release-notes/scripts/group_changes.py`. The copy I found is at `.claude/skills/release-notes/scripts/group_changes.py`, so I'll use that path.
