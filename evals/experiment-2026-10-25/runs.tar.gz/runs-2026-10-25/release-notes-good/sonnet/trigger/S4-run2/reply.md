I can't write the 1.5.0 notes yet because I don't have a list of changes. `/home/dev/project` isn't a git repo, so there's no `git log` to read. I also found no `changes.txt` or `CHANGELOG` file.

Send me one of these:
- the merged PRs or commits since the last release, pasted here
- a file path to a change list
- the previous tag and the repo location, if the git history is somewhere else

Once I have it, I'll run it through `group_changes.py` with `--version 1.5.0`. I'll put breaking changes first, then features, fixes and other changes, each with its PR number.