# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes"}
```

## tool result
```
Launching skill: release-notes
```

## assistant
I can't see the git log. Your message ended after "git log is pasted below", so the paste didn't come through. Could you paste it again? A file path, or the tag range to run `git log` on, would also work. This directory isn't a git repository, so I can't pull the log myself.

I'll draft the entry for 2.0.0 once I have it. The release-notes skill groups the changes with its script, so each entry will come from your log and carry its PR number.
