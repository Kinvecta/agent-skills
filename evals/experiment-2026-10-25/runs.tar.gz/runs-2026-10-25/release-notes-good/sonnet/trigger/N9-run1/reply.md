I couldn't find a tracker CSV. The project directory (`/home/dev/project`) has only the `release-notes` skill files, and a search of the filesystem for `*tracker*.csv` found nothing.

Where is the file? A path or a copy in the project directory is enough. If it has a different name, tell me that too.

I'd also like to know whether you have a template or a previous month's report to match. If not, I'll use a standard layout: summary, completed work, in progress, blockers and risks, and next month's priorities.