I can't find a PR to summarize. `/home/dev/project` isn't a git repository. It contains only `.claude/` and `skills/`, so there's no diff or branch to read, and `gh` can't list PRs from here.

Please send one of these and I'll write the summary:
- a PR URL or number, plus the repo if it isn't this one
- the diff pasted in
- the path to a checkout that has the branch