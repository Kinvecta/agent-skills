# session
model: claude-sonnet-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes"}
```

## tool result
```
Launching skill: release-notes
```

## tool call: Bash
```
{"command": "ls; ls .claude/skills/release-notes .claude/skills/release-notes/scripts skills/release-notes 2>&1; find . -name 'changes*.txt' -not -path './node_modules/*' | head"}
```

## tool result
```
skills
.claude/skills/release-notes:
SKILL.md
scripts
templates

.claude/skills/release-notes/scripts:
group_changes.py

skills/release-notes:
scripts
templates
```

## assistant
I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends after "Here are the merged PRs since the last tag", with nothing attached. I also looked in `/home/dev/project` and found no `changes.txt` or similar file. The directory isn't a git repo either, so I can't run `git log` against the last tag.

Any of these would work:
- Paste the PR list here, with titles and numbers.
- Give me the path to a file that has the list.
- Point me to a git checkout and the previous tag, for example `v3.0`, and I'll run `git log <previous-tag>..<new-tag>`.

Once I have the list, I'll group it with the project's `group_changes.py` script using `--version 3.1`. I'll then write the notes with breaking changes first, then features, fixes and other changes, each with its PR number.
