I can't write the 3.1 notes yet because the list of merged PRs didn't come through. Your message ends after "Here are the merged PRs since the last tag", with nothing attached. I also looked in `/home/dev/project` and found no `changes.txt` or similar file. The directory isn't a git repo either, so I can't run `git log` against the last tag.

Any of these would work:
- Paste the PR list here, with titles and numbers.
- Give me the path to a file that has the list.
- Point me to a git checkout and the previous tag, for example `v3.0`, and I'll run `git log <previous-tag>..<new-tag>`.

Once I have the list, I'll group it with the project's `group_changes.py` script using `--version 3.1`. I'll then write the notes with breaking changes first, then features, fixes and other changes, each with its PR number.