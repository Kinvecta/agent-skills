I can't tell yet. The project has no changelog, version file, or git history, so I have no changes to judge.

The rule I'd apply, assuming semver:
- **Patch** if the release only fixes bugs and leaves behavior and the public interface the same.
- **Minor** if it adds functionality in a backward-compatible way, such as a new feature, option, or command.
- **Major** if anything breaks backward compatibility.

If a release has both fixes and a new feature, it's a minor.

Tell me what's in the release, either a short description or a list of the changes, and I'll give you a specific answer. If the work lives in another directory or repo, point me to it and I'll read the changes myself.