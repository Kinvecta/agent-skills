I can't summarize a PR yet because I don't have one to read. `/home/dev/project` isn't a git repository, so there's no diff or branch, and `gh` can't find a PR from here. The directory holds only `.claude/` and `skills/`.

Any of these would let me write the summary:
- **A PR URL or number plus repo**, such as `owner/repo#123`. I can fetch it with `gh`.
- **A path to the right repo checkout**, with the branch or PR number.
- **A pasted diff or patch file.**

Once I have it, I'll write the summary with what changed and why, the files and areas touched, risky spots to look at first, and any test coverage gaps.