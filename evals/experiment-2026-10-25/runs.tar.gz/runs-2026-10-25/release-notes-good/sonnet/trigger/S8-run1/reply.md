I can't write the notes yet because I have no list of what changed in v1.0.0. `/home/dev/project` isn't a git repository, so I can't run `git log` between tags. There's also no changes file or CHANGELOG in the project.

The release-notes skill's grouping script is available. I need one of these:

1. **A changes file or pasted text.** For example, the output of `git log --oneline <previous-tag>..v1.0.0` from your real repo, or a list of merged PRs with their numbers.
2. **The path to the actual repo,** if it lives somewhere else on this machine. I can run `git log` there.

Once I have the changes, I'll group them with the script. The notes will list breaking changes first, then features, fixes and other changes, each with its PR number, under a `v1.0.0` header.

Since this is a 1.0.0, tell me whether you want a short intro line about the milestone or just the grouped list.