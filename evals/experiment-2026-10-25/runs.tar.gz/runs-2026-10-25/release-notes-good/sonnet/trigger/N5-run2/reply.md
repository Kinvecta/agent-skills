I can't tell yet. The project has no changes, version file, changelog or git history for me to judge from. It only contains `.claude` and `skills` directories.

This is the rule I'd apply under semver:
- **Patch** if the change only fixes bugs and adds no new behavior or API.
- **Minor** if it adds functionality in a backward-compatible way, such as a new feature, option or endpoint.
- **Major** if it breaks backward compatibility. (If you're below 1.0, breaking changes often go in a minor.)

If you tell me what's changing, or paste the diff or a list of merged changes, I'll give you a specific answer. I can also draft the release notes once the version is settled.