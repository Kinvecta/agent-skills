I can't find `changes.txt` anywhere on this machine. I searched the whole filesystem, and `/home/dev/project` contains only the skill files under `.claude/skills/release-notes` and `skills/release-notes`.

To write the v1.4.0 notes, I need the change list. You can:

1. **Put the file in the project.** Give me its path, or copy it to `/home/dev/project/changes.txt`.
2. **Paste the changes here.** Plain lines, a `git log` export, or a list of merged PRs all work.
3. **Use git.** If this is the repo's history, tell me the previous tag, or I can look for one once the repo is available. The shell reports `/home/dev/project` as not a git repository, so I'd need the correct directory.

Once I have the list, I'll group it with `skills/release-notes/scripts/group_changes.py --version v1.4.0`. Then I'll write the notes with breaking changes first, followed by features and fixes, each with its PR number.