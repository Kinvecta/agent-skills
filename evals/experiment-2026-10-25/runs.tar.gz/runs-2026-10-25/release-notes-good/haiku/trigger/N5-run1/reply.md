I can't tell yet. `/home/dev/project` has no git repository, no `package.json`, `pyproject.toml`, or changelog, and only `.claude/` and `skills/` directories. I can't see the change, so I don't know which version it needs.

The rule under [SemVer](https://semver.org) is:

- **Major (X.0.0):** the change breaks existing users, such as removing or renaming a public API, changing a return type, or dropping support for something.
- **Minor (x.Y.0):** the change adds backward-compatible functionality, such as a new feature, command, option, or endpoint.
- **Patch (x.y.Z):** the change is backward-compatible bug fixes, performance work, or internal refactors with no behavior change for users.

If you tell me what changed, or point me to the repo or diff, I'll pick the bump and explain why. If you also want a version bump in the project files or a changelog entry, I can make those changes too.