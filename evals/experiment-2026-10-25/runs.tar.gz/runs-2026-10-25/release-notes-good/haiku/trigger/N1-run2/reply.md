The project directory has no product code, docs, or changelog. It only contains release-notes skill files, so I don't know what v2 includes, what the product is called, or who the customers are. Rather than invent features, here's a draft with placeholders you can fill in:

---

# Introducing [Product] v2: [One-line headline about the biggest benefit]

*[Month Day, 2026]*

Today we're releasing [Product] v2, our biggest update yet. [One or two sentences on why you built it: what customers asked for, or what problem it solves.]

If you're already using [Product], here's what changes for you and what's new.

## What's new

**[Feature 1 name].** [What it does, in customer terms. Lead with the benefit.]

**[Feature 2 name].** [What it does and who it helps.]

**[Feature 3 name].** [What it does.]

## What's improved

- **[Improvement]:** [Concrete result, such as "dashboards load in under a second" or "exports handle 10x more rows."]
- **[Improvement]:** [Result.]

## What you need to do

[If there are breaking changes, list them here with migration steps. If nothing changes for existing users, say so: "Your existing setup keeps working. No action is needed."]

- [Breaking change or deprecation, and how to update]
- [Link to migration guide]

## Thank you

[A sentence or two thanking customers, ideally pointing to feedback that shaped v2.]

To get started, [call to action: link to docs, upgrade path, or a webinar].

---

**To finish this, I need:**
1. The product name and a one-line description of what it does.
2. The list of v2 changes, or a changelog, commit log, or merged PRs I can pull from. I can run the release-notes skill on it.
3. Any breaking changes and whether there's a migration guide.
4. The tone you want (formal, friendly, or technical) and the target length.
5. The publish date and the CTA link.

If you paste the changes here, I'll write the full post.