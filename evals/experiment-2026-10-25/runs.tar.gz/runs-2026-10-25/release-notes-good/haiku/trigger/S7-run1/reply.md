I can't write the 0.9.0 entry yet because the commits didn't come through with your message, and I don't want to invent changes for a release.

What I found in `/home/dev/project`:
- **No commits.** Your message doesn't include a list, and the directory isn't a git repo, so there's no history for me to read.
- **No `CHANGELOG.md`.** I'd need to create one. I'll follow the existing format if you have one elsewhere, or use a standard Keep a Changelog layout otherwise.

To continue, paste either:
1. The commit list (for example, the output of `git log --oneline v0.8.0..v0.9.0`), or
2. The path to the repo that holds those commits, so I can run the log myself.

Once I have them, I'll group the commits into Added, Changed, Fixed, and similar sections and write the 0.9.0 entry. I'll also use the `release-notes` skill for the draft if that fits your workflow. Let me know if you'd rather I create the file with a different name or location.