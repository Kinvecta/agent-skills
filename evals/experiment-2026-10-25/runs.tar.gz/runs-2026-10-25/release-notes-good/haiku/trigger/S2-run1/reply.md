I can't see the git log. Your message ends after the attribution note, so the paste didn't come through, and the project directory has no changelog or log export to fall back on.

Please paste the output again. A `git log --oneline` or `git log --pretty=format:'%h %s'` export works well. If you can include commit bodies, paste `git log --pretty=format:'%h %s%n%b'` instead, since that usually gives better entry descriptions.

Once I have it, I'll draft a 2.0.0 entry grouped into Breaking Changes, Added, Changed, Fixed, and Removed. Breaking changes will be listed first because a major version is where users most need to see them. If you know the release date, include it for the heading. I'll use today's date, 2026-10-25, if you don't.