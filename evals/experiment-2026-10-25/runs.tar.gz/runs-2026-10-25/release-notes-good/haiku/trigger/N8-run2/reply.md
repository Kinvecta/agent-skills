I couldn't find details about the release in `/home/dev/project`. It has no changelog, README, or git history, only a `release-notes` skill folder with no release content. I don't know the version or what changed, so I haven't written a tweet that would be about the wrong thing.

Tell me the version and the one or two main changes, and I'll write it. Or paste the release notes or changelog entry. Here's a draft with placeholders:

> 🚀 [Product] [version] is out!
>
> [Headline feature or fix in one line]
>
> [Second key improvement]
>
> Try it: [link]

If you'd like, I can also draft a few variations in different tones, or a short thread version.