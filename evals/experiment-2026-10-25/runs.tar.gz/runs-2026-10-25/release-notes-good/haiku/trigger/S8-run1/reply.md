I can't draft the notes yet. This directory is not a git repository, so I can't run `git log` to find what's in v1.0.0. There's also no change list here.

Send me one of these and I'll write the notes:

- **A git log export** for the range, e.g. `git log --oneline v0.x.x..v1.0.0` (or the previous tag), saved to a file. Include PR numbers if you have them.
- **A pasted list** of merged PRs or changes, one per line.
- **The repo path.** If you point me at the actual clone, I can run the git log myself.

Once I have the list, I'll run `group_changes.py --version v1.0.0`, check that every entry comes from its output, and write the notes with breaking changes first, then features, then fixes and other changes.