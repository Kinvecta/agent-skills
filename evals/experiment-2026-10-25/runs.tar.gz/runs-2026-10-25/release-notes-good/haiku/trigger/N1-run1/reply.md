The project has no v2 changelog, git history, or product docs. It only contains the release-notes skill, so I don't know what v2 actually changed. I've written a draft with bracketed placeholders where the specifics go, so nothing is invented.

---

# Introducing [Product] v2

*[Month DD, 2026]*

Today we're releasing [Product] v2. [One or two sentences on what v2 is for, in plain words: the problem it solves for customers.]

We built v2 around what you told us: [the top one or two requests from customers]. Here's what's new.

## What's new

- **[Feature 1]:** [What it does and the customer benefit, in one or two sentences.]
- **[Feature 2]:** [What it does and the customer benefit.]
- **[Feature 3]:** [What it does and the customer benefit.]

## Upgrading from v1

[If there are breaking changes, list them here, each with the step to take. If there are none, say so: "Existing v1 integrations keep working. No changes are required."]

- **[Breaking change]:** [What changed.] To upgrade, [migration step].

Full upgrade steps are in the [migration guide link].

## Fixes and improvements

- [Notable fix or improvement customers will notice.]
- [Another one.]

## Get started

[Call to action: how to upgrade, where to find the docs, or how to contact support.]

Thank you to everyone who sent feedback during the beta. Keep it coming at [feedback channel].

---

To fill this in accurately, send me one of these:

- **A changelog or list of merged changes** (a `git log v1.x.0..v2.0.0` export, or a list of PR titles). I can run it through the `release-notes` skill's grouping script and produce the features, fixes, and breaking changes sections from it.
- **Or the key points in your own words**: the headline features, any breaking changes and their migration steps, the release date, and the audience (existing customers only, or the public too).

I'll also need the product name, the release date, and the link to the migration guide, if one exists.