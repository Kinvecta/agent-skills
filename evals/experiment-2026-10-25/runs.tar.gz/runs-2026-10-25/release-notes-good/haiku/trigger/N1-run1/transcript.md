# session
model: claude-haiku-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
I'll look through the project first so the post reflects what actually changed in v2.

## tool call: Bash
```
{"command": "ls -la && find . -maxdepth 2 -not -path '*/node_modules*' -not -path '*/.git/*' \\( -iname '*changelog*' -o -iname '*release*' -o -iname 'README*' -o -iname '*v2*' -o -iname 'package.json' -o -iname '*.md' \\) | head -50", "description": "List project files and find release-related docs"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 19:55 .
drwxr-xr-x 6 root root 4096 Oct 25 19:55 ..
drwxr-xr-x 3 root root 4096 Oct 25 19:55 .claude
drwxr-xr-x 3 root root 4096 Oct 25 19:55 skills
./skills/release-notes
```

## tool call: Bash
```
{"command": "find . -type f | head -100 && echo --- && find ./skills ./.claude -type f | xargs -I{} sh -c 'echo \"== {}\"; head -c 3000 \"{}\"; echo'", "description": "List all project files and show their contents"}
```

## tool result
```
./.claude/skills/release-notes/SKILL.md
./.claude/skills/release-notes/templates/notes.md
./skills/release-notes/templates/notes.md
./.claude/skills/release-notes/scripts/group_changes.py
./skills/release-notes/scripts/group_changes.py
---
== ./.claude/skills/release-notes/SKILL.md
---
name: release-notes
description: Drafts release notes for one version from a git log export or a list of merged changes. Use when the user asks for release notes, a changelog entry, or "what's new in" a version.
---

# Release notes

## Steps

1. Get the change list (a file, pasted text, or `git log <previous-tag>..<new-tag>`). Ask for the version if you don't know it.
2. Group the changes with the script instead of sorting them yourself:
   `python3 skills/release-notes/scripts/group_changes.py changes.txt  …[truncated]
```

## assistant
The project has no v2 changelog, git history, or product docs. It only contains the release-notes skill, so I don't know what v2 actually changed. I've written a draft with bracketed placeholders where the specifics go, so nothing is invented.

---

# Introducing [Product] v2

*[Month DD, 2026]*

Today we're releasing [Product] v2. [One or two sentences on what v2 is for, in plain words: the problem it solves for customers.]

We built v2 around what you told us: [the top one or two requests from customers]. Here's what's new.

## What's new

- **[Feature 1]:** [What it does and the customer benefit, in one or two sentences.]
- **[Feature 2]:** [What it does and the customer benefit.]
- **[Feature 3]:** [What it does and the customer benefit.]

## Upgrading from v1

[If there are breaking changes, list them here, each with the step to take. If there are none, say so: "Existing v1 integrations keep working. No changes are required."]

- **[Breaking change]:** [What changed.] To upgrade, [migration step].

Full upgrade steps are in the [migration guide link].

## Fixes and improvements

- [Notable fix or improvement customers will notice.]
- [Another one.]

## Get started

[Call to action: how to upgrade, where to find the docs, or how to contact support.]

Thank you to everyone who sent feedback during the beta. Keep it coming at [feedback channel].

---

To fill this in accurately, send me one of these:

- **A changelog or list of merged changes** (a `git log v1.x.0..v2.0.0` export, or a list of PR titles). I can run it through the `release-notes` skill's grouping script and produce the features, fixes, and breaking changes sections from it.
- **Or the key points in your own words**: the headline features, any breaking changes and their migration steps, the release date, and the audience (existing customers only, or the public too).

I'll also need the product name, the release date, and the link to the migration guide, if one exists.
