I can't tell yet. The project directory at `/home/dev/project` has no source, no `package.json` or `pyproject.toml`, no changelog, and it isn't a git repo, so I can't see what changed or what the current version is.

Under semantic versioning, the rule is:

- **Patch** (1.2.3 → 1.2.4): backward-compatible bug fixes, with no new features and no changed behavior that callers depend on.
- **Minor** (1.2.3 → 1.3.0): backward-compatible new features, new options, or new endpoints.
- **Major** (1.2.3 → 2.0.0): anything that breaks existing callers. Use this even if the change is small.

If you describe the change, or point me at the repo with the diff, I'll give you a specific answer. Adding "fixes only" or "adds X" would be enough.