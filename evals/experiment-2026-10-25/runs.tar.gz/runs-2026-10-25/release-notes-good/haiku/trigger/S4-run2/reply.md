I can draft the 1.5.0 notes, but I need the change list first. `/home/dev/project` isn't a git repository, and I didn't find a changelog, log export, or list of merged PRs in it.

Could you send one of these?

1. **A git log export** from the repo that holds 1.5.0, e.g. `git log v1.4.0..v1.5.0 --oneline` (or the tag names you use), pasted here or saved as a file in the project.
2. **A list of merged changes**, one per line, with PR numbers if you have them, e.g. `#123 Add CSV export` or `#124 Fix crash on empty input`.

Once I have it, I'll group the entries with the release-notes script (breaking changes, features, fixes, other), write the notes with PR numbers, and check that the header says 1.5.0.