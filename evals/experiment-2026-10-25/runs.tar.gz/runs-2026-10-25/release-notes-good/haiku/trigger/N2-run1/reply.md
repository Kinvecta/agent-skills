I can't summarize a PR yet because I can't find one here. `/home/dev/project` is not a git repository, and `gh pr view` has no repo to read from. The directory contains only a `skills/release-notes` folder (a SKILL.md, a template, and `group_changes.py`) and a `.claude/` config directory. There's no diff, commit history, or PR metadata.

To proceed, I need one of these:

1. **The repo location.** If the code is elsewhere, give me the path and I'll run `gh pr view <number>` and `gh pr diff <number>` from there.
2. **The PR number or URL.** I'll fetch its title, description, and diff with `gh`, provided the repo is cloned and `gh` is authenticated.
3. **The diff or commit list pasted in,** if you can't share repo access.

Once I have the changes, I'll write a reviewer-oriented summary covering what changed, why, the riskiest areas, and what to check. If you do open the PR, I'll also append the required attribution line to the description if you want me to edit it.