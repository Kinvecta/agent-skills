I can't write a commit message for your staged changes because there's no git repository here. `/home/dev/project` isn't a repo, and I found no `.git` directory under `/home/dev` within four levels. The directory only contains `.claude/` and `skills/`.

To proceed, you could:
- Run me from the repository you staged changes in, or tell me its path.
- Paste the output of `git diff --staged` here, and I'll write the message from that.

Once I have the diff, I'll end the commit message with the `Co-Authored-By: Claude Haiku 5.5 <[email removed]>` line you specified.