# v2.0.0

## Breaking changes

- **Config is now read from `tidy.toml`.** `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once. (#152, Raj Patel)
- **Python 3.9 is no longer supported.** (#146, Ana Ruiz)
  *Migration note needed: the commit has no `BREAKING CHANGE` note. Add one before publishing.*

## Fixes

- **CLI:** the exit code is now 1 instead of 0 when a file is missing. (#149, Sam Okafor)

## Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

**For you, not for the published notes:**

- **#148 is left out.** Its subject line is malformed: `feat(api add pagination to list endpoint (#148)` is missing the `)` after `api`. It looks like a feature (pagination on the list endpoint), so please confirm it and I'll add it under Features. The commit message can't be fixed without rewriting history, so the entry will need to be written by hand.
- **#151 (bulk delete endpoint) is left out.** Commit `f1e2d3c` reverts it.
- **Chores are left out:** the `requests` bump (#153), the `actions/checkout` v7 bump, and the merge commit for #152. If the checkout bump matters to users, you may want to mention it.
- **Features is empty** because the only feature in the log, #148, is the malformed one above.

Source: `/home/dev/project/git-log-tricky.txt`. Grouped with `/home/dev/project/.claude/skills/release-notes/scripts/group_changes.py`.