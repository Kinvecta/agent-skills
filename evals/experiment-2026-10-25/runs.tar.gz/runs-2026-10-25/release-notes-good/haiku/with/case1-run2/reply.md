# 1.4.0 (2026-10-25)

This release adds CSV export, makes uploads and sync more reliable, and speeds up search indexing.

### Features

- Add `--format csv` to the export command (#142)
- Show a progress bar for uploads over 10 MB (#138)

### Fixes

- Sync retries once when the server returns 503 (#140)
- Config file paths with spaces are no longer split (#137)

### Other changes

- Document the export command in the README (#135)
- Build the search index in one pass, which is faster (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

Notes:
- **Release date:** the git log has no tag date, so I used today's date (2026-10-25). Change it to the actual release date if it differs.
- **Breaking changes:** none were found, so that section is left out.
- **Left out:** one `chore` commit (version bump) and one `ci` commit (pip caching) are internal and were not listed. Lee Chen authored both, so Lee is not in the contributors list. Add Lee if you want them credited.