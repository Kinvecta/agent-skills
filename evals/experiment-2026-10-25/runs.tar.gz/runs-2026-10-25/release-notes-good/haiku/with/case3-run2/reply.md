# v2.0.0 release notes (draft)

## Breaking changes

- **Config is now read from `tidy.toml`.** `tidy.ini` is no longer read. Rename it to `tidy.toml`, then run `tidy config migrate` once. (#152, Raj Patel)
- **Python 3.9 is no longer supported.** (#146, Ana Ruiz)
  - *No migration note was in the commit message. Please add one, for example the minimum supported version.*

## Fixes

- **CLI:** the exit code is now 1, not 0, when a file is missing. (#149, Sam Okafor)

## Contributors

Ana Ruiz, Raj Patel, Sam Okafor

## Items that need your decision

- **Pagination for the list endpoint (#148, Lee Chen) is left out.** The commit subject is `feat(api add pagination to list endpoint (#148)`, with the closing parenthesis after the scope missing. The grouping script couldn't parse its type, so it isn't in the notes. If it ships in 2.0.0, it belongs under Features, and Lee Chen should be added to Contributors. Fixing the commit subject would also make it parse.
- **Bulk delete endpoint (#151) is not listed.** It was reverted in f1e2d3c, so I left it out.
- **Dependency bumps are not listed.** Dependabot (#153) and Renovate commits are excluded as chores.

The release date and any upgrade steps for Python 3.9 aren't in the log, so I've left them out.