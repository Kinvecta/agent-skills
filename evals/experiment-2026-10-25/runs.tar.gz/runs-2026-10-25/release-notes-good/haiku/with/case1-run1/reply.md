# 1.4.0 Release Notes

### Features

- **export:** add `--format csv` to the export command (#142, Ana Ruiz)
- show a progress bar for uploads over 10 MB (#138, Ana Ruiz)

### Fixes

- **sync:** retry once when the server returns 503 (#140, Raj Patel)
- config file paths with spaces are no longer split (#137, Sam Okafor)

### Other Changes

- **index:** build the search index in one pass (#134, Sam Okafor)
- **readme:** document the export command (#135, Raj Patel)

Thanks to Ana Ruiz, Raj Patel, and Sam Okafor for this release.

There are no breaking changes in this release. I left out the version bump, CI caching, and other maintenance commits from the notes.