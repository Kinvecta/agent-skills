I've drafted the v2.0.0 release notes from the grouping script's output. Two commits need your input before this goes out (see below the draft).

---

# v2.0.0

## ⚠️ Breaking changes

- **config:** Settings are now read from `tidy.toml` (#152)
  `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once.
- Support for Python 3.9 has been dropped (#146)

## Bug fixes

- **cli:** The exit code is now 1, not 0, when a file is missing (#149)

## Contributors

Thanks to Ana Ruiz, Raj Patel and Sam Okafor.

---

**Needs your input:**

1. **The pagination feature (#148) is missing from the notes.** Its commit message has a typo (`feat(api add pagination…`, missing the `)`), so the script couldn't read it and left it out. It's clearly a user-facing feature. Should I add it as a "Features" entry: "**api:** Add pagination to the list endpoint (#148)"? If I do, Lee Chen should also go in the contributors list.
2. **The Python 3.9 removal (#146) has no upgrade note.** The commit doesn't say which Python version users now need. Could you confirm it? Then I can add a line like "Upgrade to Python 3.10 or later."

**Left out on purpose:**
- The bulk delete endpoint (#151) was added and then reverted in this release, so it doesn't ship.
- Two automated dependency updates (requests 2.32.4, actions/checkout v7) and one merge commit were left out because they don't affect users.