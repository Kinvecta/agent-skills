## v2.0.0

### ⚠️ Breaking changes

- **config:** Settings are now read from `tidy.toml`. `tidy.ini` is no longer read. Rename it to `tidy.toml` and run `tidy config migrate` once. (#152)
- Python 3.9 is no longer supported. (#146)

### Bug fixes

- **cli:** The exit code is now 1, not 0, when a file is missing. (#149)

### Contributors

Thanks to Ana Ruiz, Raj Patel and Sam Okafor.

---

**Before you publish, check these:**

1. **The pagination feature (#148) is missing.** Its commit subject has a typo, `feat(api add pagination…` with no closing `)`, so the grouping script couldn't parse it and left it out. It looks like a real user-facing feature. I didn't add it myself because the skill says every entry must come from the script's output. If you want it in, add this under a "Features" section: `- **api:** Add pagination to the list endpoint. (#148)`
2. **The Python 3.9 removal (#146) has no migration note.** I didn't guess at the new minimum Python version. If it's 3.10, say so in that entry. Also, this commit is typed `fix!`, but it reads more like a breaking change than a bug fix. That doesn't change where it goes in the notes.

**Left out on purpose:**
- **Bulk delete endpoint (#151):** added and then reverted in this same range, so it doesn't ship.
- Two dependency bumps from bots (requests 2.32.4 in #153, and actions/checkout v7) and one merge commit.

The header version (v2.0.0) matches the version I passed to the script.