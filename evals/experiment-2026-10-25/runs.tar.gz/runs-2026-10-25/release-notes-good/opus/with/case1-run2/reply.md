Release notes for 1.4.0:

```markdown
# 1.4.0

## Features
- **export:** Add `--format csv` to the export command (#142)
- Show a progress bar for uploads over 10 MB (#138)

## Fixes
- **sync:** Retry once when the server returns 503 (#140)
- Config file paths with spaces are no longer split (#137)

## Other changes
- **index:** Build the search index in one pass (#134)
- **readme:** Document the export command (#135)

Thanks to Ana Ruiz, Raj Patel and Sam Okafor for their contributions.
```

I ran the skill's grouping script on `git-log-1.4.0.txt` with `--version 1.4.0`. It reported no problems. Every entry above comes from its output, and the header matches the version I passed in.

- **Not in the notes:** two internal commits, a version bump (chore) and pip caching in CI (ci). This follows the skill's rule of listing only changes users would notice.
- **No breaking changes or reverts** in this range.
- **Contributors:** the list includes only authors of changes that appear in the notes, so Lee Chen isn't in it. Lee wrote the two internal commits. Add Lee if you want to credit everyone who committed.

I didn't save these to a file. Tell me where they should go, such as `CHANGELOG.md`, and I'll add them.