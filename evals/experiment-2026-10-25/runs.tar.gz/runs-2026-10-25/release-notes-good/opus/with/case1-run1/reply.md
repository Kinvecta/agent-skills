## 1.4.0 (YYYY-MM-DD)

This release adds CSV export and an upload progress bar. It also makes sync more reliable and fixes config paths that contain spaces.

### Features

- The `export` command can now write CSV with `--format csv`. (#142)
- Uploads over 10 MB now show a progress bar. (#138)

### Fixes

- Sync now retries once when the server returns a 503 error. (#140)
- Config file paths that contain spaces are no longer split into separate arguments. (#137)

### Other changes

- The README now documents the `export` command. (#135)
- The search index is now built in a single pass, which makes it faster. (#134)

### Contributors

Ana Ruiz, Raj Patel, Sam Okafor

---

- **Release date:** the log doesn't include one, so the header has a `YYYY-MM-DD` placeholder. The newest commit is from 2026-10-19; send me the actual date and I'll fill it in.
- **Checks:** every entry comes from the grouping script's output, and the header version is 1.4.0. There are no breaking changes and no reverted commits.
- **Left out:** one `chore` commit (a version bump) and one `ci` commit (pip caching). Because of that, Lee Chen, who wrote both, isn't in the contributors list. If you want to credit them, I can add them.