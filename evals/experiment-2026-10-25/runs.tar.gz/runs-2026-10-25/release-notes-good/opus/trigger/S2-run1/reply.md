The git log didn't come through. Your message ends at "pasted below" and nothing follows it. Also, `/home/dev/project` isn't a git repository, so I can't run `git log` myself.

Could you send it again? Any of these would work:

- **Paste the output**, for example from `git log v1.x.x..v2.0.0 --oneline` (or `--pretty=format:"%h %s"`) run against the previous release tag.
- **Give me a path** to a file containing the log export.
- **Give me the repo path** if the project is somewhere else, and I'll pull the log myself.

It would also help to know the previous version tag, plus any existing changelog format or file (like `CHANGELOG.md`) I should match. Once I have the log, I'll draft the 2.0.0 entry with breaking changes listed first, since this is a major version.