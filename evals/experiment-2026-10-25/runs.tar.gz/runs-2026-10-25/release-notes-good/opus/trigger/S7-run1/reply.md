I need the commit list before I can write the 0.9.0 entry. None came through with your message, and I couldn't find one in the project:

- `/home/dev/project` isn't a git repository, so I can't run `git log` to get them.
- There's no `CHANGELOG.md` yet, only the release-notes skill files.

Could you paste the commits, or give me the path to a file with them (for example the output of `git log v0.8.0..v0.9.0 --oneline`)? Once I have them, I'll group them with the skill's script and create `CHANGELOG.md` with a 0.9.0 section: breaking changes first, then features, fixes and other changes, each with its PR number.

If the changelog is somewhere else, tell me where and I'll add the entry there.