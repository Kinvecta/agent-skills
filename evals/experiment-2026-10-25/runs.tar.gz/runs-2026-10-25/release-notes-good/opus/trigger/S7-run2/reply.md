I can't write the 0.9.0 entry yet because I don't have the commits. Your message says "using these commits", but no commit list came through with it, and I can't pull one myself:

- `/home/dev/project` isn't a git repository, so I can't run `git log`.
- There's no `CHANGELOG.md` in the project. The only files are the release-notes skill and its script and template.
- I didn't find a commit list or changes file anywhere in the project.

Could you send one of these?

1. **The commit list**, pasted in or as a file path, e.g. the output of `git log --oneline v0.8.0..v0.9.0`, including PR numbers.
2. **Where the changelog lives.** If it's in another repo, give me that path. If you want a new `CHANGELOG.md` in `/home/dev/project`, tell me and I'll create one.

Once I have the commits, I'll group them with the skill's script and add a 0.9.0 section: breaking changes first, then features, fixes and other changes, each with its PR number.