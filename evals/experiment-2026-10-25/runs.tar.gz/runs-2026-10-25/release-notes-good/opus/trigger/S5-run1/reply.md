I can't find a git log to work from. `/home/dev/project` isn't a git repository and has no log file in it, only the `skills` and `.claude` folders.

To write the release notes I need two things:

1. **The change list.** You can paste the `git log` output here, give me a path to a file containing it, or point me to the repo and the tag range (e.g. `v1.3.0..v1.4.0`).
2. **The version number** for the release-notes header (e.g. `1.4.0`).

Once I have those, I'll group the commits with the release-notes script and write the notes: breaking changes first, then features, fixes and other changes, each with its PR number.