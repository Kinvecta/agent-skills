# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## assistant
The git log didn't make it into your message. Nothing came through after "pasted below." The working directory also isn't a git repo, so I can't pull the log myself.

Can you paste it again? Output from something like this works well:

```
git log v1.x.x..v2.0.0 --oneline --no-merges
```

If you have merged PR titles or commits with longer bodies, include those too. They help me spot breaking changes, which matter most for a major version like 2.0.0.
