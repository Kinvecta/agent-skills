I can't find the list of fixes. Nothing came through with your message, the project has no changes file (only the release-notes skill files), and this directory isn't a git repo, so I can't pull a `git log` either.

Can you paste the list here or give me the path to a file? Any of these works:
- One line per change, ideally with PR numbers (e.g. `Fix crash when config is empty (#142)`)
- A `git log --oneline v1.2.0..v1.2.1` export
- The path to a repo where I can run that `git log` myself

Once I have it, I'll group the changes with the skill's script and write the 1.2.1 notes from the result.