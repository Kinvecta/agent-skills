# session
model: claude-opus-5-5
skills listed: release-notes, deep-research, design, slides, design-sync, dataviz, artifact-diagramming, artifact-capabilities, update-config, verify, debug, code-review, simplify, batch, fewer-permission-prompts, doctor, explain-usage, setup-claude, loop, claude-api, workflow-authoring, claude-in-chrome, run, run-skill-generator, plugin-authoring

## tool call: Skill
```
{"skill": "release-notes", "args": "3.1"}
```

## tool result
```
Launching skill: release-notes
```

## tool call: Bash
```
{"command": "ls -la /home/dev/project; ls /home/dev/project/.claude/skills/release-notes/scripts", "description": "List project files and skill scripts"}
```

## tool result
```
total 16
drwxr-xr-x 4 root root 4096 Oct 25 19:58 .
drwxr-xr-x 6 root root 4096 Oct 25 19:58 ..
drwxr-xr-x 3 root root 4096 Oct 25 19:58 .claude
drwxr-xr-x 3 root root 4096 Oct 25 19:58 skills
group_changes.py
```

## assistant
I can't find the PR list. It didn't come through with your message, there's no changes file in `/home/dev/project`, and the directory isn't a git repo, so I can't pull a `git log` from the last tag either.

Could you send the merged PRs one of these ways?

- **Paste them here.** One per line is enough, e.g. `#412 Add retry option to client (feat)`.
- **Give me a file path** to an exported list.
- **Point me to the repo checkout** and the previous tag, and I'll run `git log <previous-tag>..HEAD` myself.

Once I have the list, I'll group it with the skill's script and write the 3.1 notes: breaking changes first, then features, fixes and other changes, each with its PR number.
