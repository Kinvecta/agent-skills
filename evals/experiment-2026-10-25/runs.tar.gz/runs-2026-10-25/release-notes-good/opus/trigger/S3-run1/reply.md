I can't find the PR list. It didn't come through with your message, there's no changes file in `/home/dev/project`, and the directory isn't a git repo, so I can't pull a `git log` from the last tag either.

Could you send the merged PRs one of these ways?

- **Paste them here.** One per line is enough, e.g. `#412 Add retry option to client (feat)`.
- **Give me a file path** to an exported list.
- **Point me to the repo checkout** and the previous tag, and I'll run `git log <previous-tag>..HEAD` myself.

Once I have the list, I'll group it with the skill's script and write the 3.1 notes: breaking changes first, then features, fixes and other changes, each with its PR number.