I can't write that tweet yet because I don't know what's in the release. This directory isn't a git repo, and it has no changelog, release notes or package manifest. The only files are the `release-notes` skill's own files: a template and a grouping script.

Could you send me one of these?
- **The release notes or changelog entry**, or just a few bullet points of what's new
- **The product name and version number**
- **A git log export or list of merged PRs.** I can use the `release-notes` skill to draft notes from it first, then write the tweet from those notes.

It would also help to know the tone you want (playful, straightforward or technical), whether to include a link or hashtags, and whether you want one tweet or a short thread.