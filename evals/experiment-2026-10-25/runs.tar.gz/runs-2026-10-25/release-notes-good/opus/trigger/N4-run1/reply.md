I can't write a message yet: `/home/dev/project` isn't a git repository, so there are no staged changes to read. Git returned "fatal: not a git repository" for this directory and its parent folders.

To get a message, you can either:
- **Point me to the repo.** If the project is in another directory, give me the path and I'll read the staged diff there.
- **Paste the diff.** Run `git diff --cached` wherever your repo is and paste the output here.