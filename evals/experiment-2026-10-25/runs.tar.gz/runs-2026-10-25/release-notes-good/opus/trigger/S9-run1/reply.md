I can't find the list of fixes. Nothing came through with your message, and the project has no changes file or git history to pull from. The directory only holds the release-notes skill and its grouping script.

Please send the list in one of these ways:
- **Paste it here**, one change per line, ideally with PR numbers (e.g. `Fix crash when config is empty (#412)`)
- **Give a file path** to a changes file
- **Give a git range** (e.g. `v1.2.0..v1.2.1`) if the repo is somewhere else

Once I have it, I'll run it through the grouping script and write the 1.2.1 notes.