I couldn't find any staged changes. `/home/dev/project` isn't a git repository, and git didn't find one in any parent directory either.

To get a commit message, you could:
- Tell me where the repository is, if it's in another directory, or
- Paste the output of `git diff --cached` from your repo here.

Either way, I'll write a message that matches what the changes do.