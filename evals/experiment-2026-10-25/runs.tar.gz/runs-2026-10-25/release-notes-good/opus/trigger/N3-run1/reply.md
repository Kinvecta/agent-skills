I can't write this yet because nothing in this workspace describes the 1.4.1 fix. `/home/dev/project` isn't a git repository and has no source code, changelog or commit history. The only files in it belong to the `release-notes` skill. I'd rather not guess at the vulnerability's details, since a wrong affected range or a made-up root cause in an advisory would mislead users.

To draft it, I need some of the following:

1. **Something to work from**, whichever is easiest: the fix commit or PR diff, the issue or report, a `git log` export for 1.4.0..1.4.1, or the path to the repo.
2. **Product or package name** and ecosystem (npm, PyPI, etc.).
3. **Affected versions**, e.g. `>= 1.2.0, < 1.4.1`, and when the bug was introduced if known.
4. **What the bypass is:** which endpoint or component, what an attacker can do, and what conditions it needs (unauthenticated? a specific config?).
5. **Severity:** a CVSS score or vector if you have one. Otherwise I can propose one from the details.
6. **Workarounds** for users who can't upgrade right away, if any exist.
7. **Identifiers and credits:** a CVE or GHSA ID if one is assigned, and the reporter's name if they want credit.
8. **Format:** GitHub Security Advisory, a `SECURITY.md`-style notice, a mailing-list post, or something else.

If you share the repo path or the fix diff, I can work out most of items 3 to 6 from the code myself and send you the rest as questions.