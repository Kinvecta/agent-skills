I can draft the 3.1 notes, but the list of merged PRs didn't come through with your message. Nothing in the project holds it either: there's no changes file, and the directory isn't a git repo, so I can't run `git log` from the last tag.

You can send it one of these ways:
- Paste the PR list here (one per line, like `#123 Add X`), or
- Give me the path to a file that has it, or
- Point me to the repo and the last tag name, and I'll pull the log myself.

Once I have it, I'll run the release-notes grouping script and write the notes with breaking changes first, then features, fixes and other changes, each with its PR number.